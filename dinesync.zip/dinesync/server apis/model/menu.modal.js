const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const MenuSchema = new Schema({
    number:{
        type:String,
    },
    itemname:{
        type:String,
    },
    itemprice:{
        type:String,
    },
    itemdes:{
        type:String,
    },
    itemrating:{
        type:String,
    },
    itemuser:{
        type:String,
    },
    cat:{
        type:String,
    },
    mcat:{
        type:String,
    },
    image:[
        {
            type: String,
        },
    ],
    reviews:[],
});

const menuModel = db.model('menu',MenuSchema);
module.exports = menuModel;
