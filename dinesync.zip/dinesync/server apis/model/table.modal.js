const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const tableSchema = new Schema({
    number:{
        type:String,
    },
    people:{
        type:String,
    },
    des:{
        type:String,
    },
});

const tableModel = db.model('table',tableSchema);
module.exports = tableModel;
