const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const orderSchema = new Schema({
    restnumber:{
        type:String,
    },
    custnumber:{
        type:String,
    },
    family:{
        type:String,
    },
    datetime:{
        type:String,
    },
    table:{
        type:String,
    },
    menu:[
        {
            type: Map,
        },
    ],
    timee:{
        type:String,
    },
    times:{
        type:String,
    },
    status:{
        type:String,
    },
});

const orderModel = db.model('order',orderSchema);
module.exports = orderModel;
