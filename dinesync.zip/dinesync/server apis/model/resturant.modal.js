const mongoose = require('mongoose');
const db = require('../config/db');

const { Schema } = mongoose;

const resturantSchema = new Schema({
    number:{
        type:String,
    },
    name:{
        type:String,
    },
    des:{
        type:String,
    },
    mons:{
        type:String,
    },
    mone:{
        type:String,
    },
    tues:{
        type:String,
    },
    tuee:{
        type:String,
    },
    weds:{
        type:String,
    },
    wedn:{
        type:String,
    },
    thus:{
        type:String,
    },
    thue:{
        type:String,
    },
    fris:{
        type:String,
    },
    fire:{
        type:String,
    },
    sats:{
        type:String,
    },
    sate:{
        type:String,
    },
    suns:{
        type:String,
    },
    sune:{
        type:String,
    },
    image:[
        {
            type: String,
        },
    ],
});

const resturantModel = db.model('resturant',resturantSchema);
module.exports = resturantModel;
