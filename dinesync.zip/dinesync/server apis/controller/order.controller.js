const orderService = require('../services/order.service');
const moment = require('moment');

exports.registeroder = async(req,res,next)=>{
    try{
        const {restnumber,custnumber,family,table,menu,times,timee,datetime,status} = req.body;
        const response = await orderService.registeroder(restnumber,custnumber,family,table,menu,times,timee,datetime,status);
        res.json({status:true,sucess:"order registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}

exports.updatestatus = async(req,res,next)=>{
    try{
        const {id,status} = req.body;
        await orderService.updatestatus(id,status);
        res.status(200).json({status:true});
    } catch (e){
        console.log(e)
        res.json({status:false});
    }
}

exports.getbyrest = async(req,res,next)=>{
    try{
        const {restnumber} = req.body;
        const rest = await orderService.getbyrest(restnumber);
        if(!rest){
            res.status(200).json({status:false,message:"no order found"});
        } else{
            res.status(200).json({status:true,rest:rest,message:"order founded"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}

exports.getbyuser = async(req,res,next)=>{
    try{
        const {custnumber} = req.body;
        const rest = await orderService.getbyuser(custnumber);
        if(!rest){
            res.status(200).json({status:false,message:"no order found"});
        } else{
            res.status(200).json({status:true,rest:rest,message:"order founded"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.restsale = async(req,res,next)=>{
    try{
        const {restnumber} = req.body;
        const rest = await orderService.getbyrest(restnumber);
        if(!rest){
            res.status(200).json({status:false,message:"no order found"});
        } else{
            const groupedOrders = await groupOrdersByDate(rest);
            res.status(200).json({status:true,rest:groupedOrders,message:"order founded"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


function groupOrdersByDate(orders) {
    const grouped = {};

    orders.forEach(order => {
        const date = moment(order.datetime).format('YYYY-MM-DD');
        if (!grouped[date]) {
            grouped[date] = 0;
        }
        order.menu.forEach(item => {
            const itemObj = Object.fromEntries(item);
            const editPrice = parseInt(itemObj.editprice, 10);
            if (!isNaN(editPrice)) {
                grouped[date] += editPrice;
            }
        });
    });

    return grouped;
}
