const tableService = require('../services/table.service');
const orderService = require('../services/order.service');
const moment = require('moment');

exports.registertable = async(req,res,next)=>{
    try{
        const {number,people,des} = req.body;
        const response = await tableService.registertable(number,people,des);
        res.json({status:true,sucess:"table registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}


exports.alltable = async (req, res, next) => {
    try {
      const { number, number2, date, times, timee } = req.body;
      const rest = await tableService.alltable(number);
      const orders = await orderService.getallorder();
      if (!rest) {
        res.status(200).json({ status: false, rest: [], message: "no rest found" });
      } else {
        const timess = moment(times, 'h:mm A');
        const timeee = moment(timee, 'h:mm A');
        const simplifiedRest = rest.map((table, index) => {
          const { _id, number, people, des } = table;
            const hasConflictingOrder = orders.some(
            (order) =>
              order.datetime.split(' ')[0] === date &&
              order.table === "t" + (index + 1) &&
              moment(order.times, 'h:mm A').isBetween(timess, timeee, null, '[)') ||
              order.datetime.split(' ')[0] === date &&
              order.table === "t" + (index + 1) &&
              moment(order.timee, 'h:mm A').isBetween(timess, timeee, null, '[)')
          );
          return { _id, number, people, des, exist: hasConflictingOrder };
        });
        res.status(200).json({ status: true, rest: simplifiedRest, message: "login in successfully" });
      }
    } catch (e) {
      console.log(e);
      res.json({ status: false, success: "server error controller login" });
    }
  };
  

exports.updatetable = async(req,res,next)=>{
    try{
        const {id,people,des} = req.body;
        const rest = await tableService.updatedtable(id,people,des);
        if (!rest) {
            res.status(200).json({status:true,rest:rest,message:"update in sucessfully"});
        } else{
            res.status(200).json({status:false,message:"no rest found"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.deletetable = async(req,res,next)=>{
    try{
        const {id} = req.body;
        const rest = await tableService.deletetable(id);
        if(!rest){
            res.status(200).json({status:true,message:"deleted table"});
        } else{
            res.status(200).json({status:false,message:"no table found"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}