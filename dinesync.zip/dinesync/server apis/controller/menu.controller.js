const menuService = require('../services/menu.service');

exports.registermenu = async(req,res,next)=>{
    try{
        const {number,itemname,itemprice,itemdes,itemrating,itemuser,image,cat,mcat,reviews} = req.body;
        const response = await menuService.registermenu(number,itemname,itemprice,itemdes,
            itemrating,itemuser,image,cat,mcat,reviews);
        res.json({status:true,sucess:"table registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}

exports.allmenu = async(req,res,next)=>{
    try{
        const {number,mcat} = req.body;
        var rest;
        if(mcat === ""){
            rest = await menuService.allmenuff(number);
        } else {
            rest = await menuService.allmenu(number,mcat);
        }
        res.status(200).json({status:true,rest:rest,message:"login in sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}

exports.updatedmenu = async(req,res,next)=>{
    try{
        const {id,itemname,itemprice,itemdes,image,cat,mcat} = req.body;
        const rest = await menuService.updatedmenu(id,itemname,itemprice,itemdes,image,cat,mcat);
        if (!rest) {
            res.status(200).json({status:true,rest:rest,message:"update in sucessfully"});
        } else{
            res.status(200).json({status:false,message:"no rest found"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}

exports.updatedmenurating = async(req,res,next)=>{
    try{
        const {id,itemrating,rdata} = req.body;
        const rest = await menuService.updatedmenuuser(id);
        const rest1 = await menuService.updatedmenurating(id,itemrating);
        const rest2 = await menuService.updatedrlist(id,rdata);
        res.status(200).json({status:true,rest:rest,message:"update in sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}

exports.deletemenu = async(req,res,next)=>{
    try{
        const {id} = req.body;
        const rest = await menuService.deletemenu(id);
        if(!rest){
            res.status(200).json({status:true,message:"deleted table"});
        } else{
            res.status(200).json({status:false,message:"no table found"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}
