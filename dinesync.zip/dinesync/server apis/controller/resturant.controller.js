const resturantService = require('../services/resturant.service');

exports.registerRest = async(req,res,next)=>{
    try{
        const {number,name,des,mons,mone,tues,tuee,weds,wede,thus,thue,firs,fire,sats,sate,suns,sune,image} = req.body;
        const response = await resturantService.registerRest(number,name,des,mons,mone,tues,tuee,weds,wede,thus,thue,firs,fire,sats,sate,suns,sune,image);
        res.json({status:true,sucess:"User registered Sucessfully"});
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller register"});
    }
}


exports.checkrest = async(req,res,next)=>{
    try{
        const {number} = req.body;
        const rest = await resturantService.checkrest(number);
        if(!rest){
            res.status(200).json({status:false,message:"no rest found"});
        } else{
            res.status(200).json({status:true,rest:rest,message:"login in sucessfully"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.updaterest = async(req,res,next)=>{
    try{
        const {number,name,des,mons,mone,tues,tuee,weds,wede,thus,thue,firs,fire,sats,sate,suns,sune,image} = req.body;
        const rest = await resturantService.updatedrest(number,name,des,mons,mone,tues,tuee,weds,wede,thus,thue,firs,fire,sats,sate,suns,sune,image);
        if(!rest){
            res.status(200).json({status:true,rest:rest,message:"update in sucessfully"});
        } else{
            res.status(200).json({status:false,message:"no rest found"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}


exports.allrest = async(req,res,next)=>{
    try{
        const {} = req.body;
        const rest = await resturantService.allrest();
        if(!rest){
            res.status(200).json({status:false,message:"no rest found"});
        } else{
            res.status(200).json({status:true,rest:rest,message:"login in sucessfully"});
        }
    } catch (e){
        console.log(e)
        res.json({status:false,sucess:"server error controller login"});
    }
}