const ordermodel = require('../model/order.modal');

class orderService{
   static async registeroder(restnumber,custnumber,family,table,menu,times,timee,datetime,status){
        try{
            const creteorder = new ordermodel({restnumber,custnumber,family,table,menu,times,timee,datetime,status});
            return await creteorder.save();
        } catch(e){
            console.log(e)
            res.json({status:false,sucess:"server error service register"});
        }
   }

   static async getbyrest(restnumber){
    try{
        return await ordermodel.find({restnumber}).sort({datetime:-1});
    } catch(e){
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async updatestatus(id,status){
    try{
        return await ordermodel.findByIdAndUpdate(id,{$set:{status:status}});
    } catch(e){
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async getbyuser(custnumber){
    try{
        return await ordermodel.find({custnumber}).sort({datetime:-1});
    } catch(e){
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }


   static async getallorder(){
    try{
        return await ordermodel.find().sort({datetime:-1});
    } catch(e){
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

}

module.exports = orderService;