const restmodel = require('../model/resturant.modal');

class resturantService{
   static async registerRest(number,name,des,mons,mone,tues,tuee,weds,wede,thus,thue,firs,fire,sats,sate,suns,sune,image){
        try{
            const creterest = new restmodel({number,name,des,mons,mone,tues,tuee,weds,wede,thus,thue,firs,fire,sats,sate,suns,sune,image});
            return await creterest.save();
        } catch(e){
            console.log(e)
            res.json({status:false,sucess:"server error service register"});
        }
   }

   static async checkrest(number){
    try{
        return await restmodel.findOne({number});
    } catch(e){
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async updatedrest(number,name,des,mons,mone,tues,tuee,weds,wede,thus,thue,firs,fire,sats,sate,suns,sune,image){
    try{
        await restmodel.findOneAndUpdate({number}, { $set: { name: name,des:des,mons:mons,mone:mone,tues:tues,tuee:tuee,
            weds:weds,wede:wede,thus,thus,thue:thue,firs:firs,fire:fire,sats:sats,sate:sate,suns:suns,sune:sune,image:image  } });
    } catch(e){
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async allrest(){
    try{
        return await restmodel.find();
    } catch(e){
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

}

module.exports = resturantService;