const menumodel = require('../model/menu.modal');

class menuService{
   static async registermenu(number,itemname,itemprice,itemdes,itemrating,itemuser,image,cat,mcat,reviews){
        try{
            const cretemenu = new menumodel({number,itemname,itemprice,itemdes,
                itemrating,itemuser,image,cat,mcat,reviews});
            return await cretemenu.save();
        } catch(e){
            console.log(e)
            res.json({status:false,sucess:"server error service register"});
        }
   }
   
   static async allmenu(number,mcat){
    try{
        return await menumodel.find({number,mcat});
    } catch(e){
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async allmenuff(number){
    try{
        return await menumodel.find({number});
    } catch(e){
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async updatedmenu(id,itemname,itemprice,itemdes,image,cat,mcat){
    try {
        await menumodel.findByIdAndUpdate(id,
             { $set: {itemname:itemname,itemprice:itemprice,itemdes:itemdes,image:image,cat:cat,
                mcat:mcat}});
    } catch(e) {
        console.log(e)
        res.json({status:false,sucess:"server error service chcekuser"});
    }
   }


   static async updatedmenurating(id,itemrating){
    try {
        await menumodel.findByIdAndUpdate(id,{ $set: {itemrating:itemrating}});
    } catch(e) {
        console.log(e)
        res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async updatedmenuuser(id){
    try {
        const u = await menumodel.findById(id);
        u.itemuser = (parseInt(u.itemuser) + 1).toString();
        await menumodel.findByIdAndUpdate(id,{ $set: {itemuser:u.itemuser}});
    } catch(e) {
        console.log(e)
        res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async updatedrlist(id,data){
    try {
        const u = await menumodel.findById(id);
        u.reviews.push(data);
        await menumodel.findByIdAndUpdate(id,{$set:{reviews:u.reviews}});
    } catch(e) {
        console.log(e)
        res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async deletemenu(id){
    try {
        await menumodel.findByIdAndDelete(id);
    } catch(e) {
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

}

module.exports = menuService;
