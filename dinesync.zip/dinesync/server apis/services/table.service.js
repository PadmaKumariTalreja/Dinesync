const tablemodel = require('../model/table.modal');

class tableService{
   static async registertable(number,people,des){
        try{
            const cretetable = new tablemodel({number,people,des});
            return await cretetable.save();
        } catch(e){
            console.log(e)
            res.json({status:false,sucess:"server error service register"});
        }
   }
   
   static async alltable(number){
    try{
        return await tablemodel.find({number});
    } catch(e){
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async updatedtable(id,people,des){
    try {
        await tablemodel.findByIdAndUpdate(id,
             { $set: { people:people,des:des}});
    } catch(e) {
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

   static async deletetable(id){
    try {
        await tablemodel.findByIdAndDelete(id);
    } catch(e) {
        console.log(e)
            res.json({status:false,sucess:"server error service chcekuser"});
    }
   }

}

module.exports = tableService;