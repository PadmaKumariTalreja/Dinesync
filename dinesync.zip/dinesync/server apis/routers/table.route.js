const router = require('express').Router();
const tableController = require('../controller/table.controller');

router.post("/registertable",tableController.registertable);
router.post("/alltable",tableController.alltable);
router.post("/updatetable",tableController.updatetable);
router.post("/deletetable",tableController.deletetable);

module.exports = router;
