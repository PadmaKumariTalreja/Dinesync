const router = require('express').Router();
const menuController = require('../controller/menu.controller');

router.post("/registermenu",menuController.registermenu);
router.post("/allmenu",menuController.allmenu);
router.post("/updatedmenu",menuController.updatedmenu);
router.post("/updatedmenurating",menuController.updatedmenurating);
router.post("/deletemenu",menuController.deletemenu);

module.exports = router;
