const router = require('express').Router();
const resrController = require('../controller/resturant.controller');

router.post("/registerrest",resrController.registerRest);
router.post("/checkrest",resrController.checkrest);
router.post("/updaterest",resrController.updaterest);
router.post("/allrest",resrController.allrest);

module.exports = router;
