const complaint = require('../model/complaint.modal');
const app = require('express').Router();

app.post('/registercomplaint', async (req, res, next) => {
    try {
      const { title, des } = req.body;
      const user = new complaint({title, des});
      await user.save();
      res.status(200).json({ status:true ,message:"register sucessfully"});
    } catch (error) {
      console.log(error);
      res.status(500).json({ status:false,message:"try again later" });
    }
});

app.post('/allcomplaint', async (req, res, next) => {
    try {
      const user = await complaint.find();
      res.status(200).json({ status:true ,data:user});
    } catch (error) {
      console.log(error);
      res.status(500).json({ status:false,data:[] });
    }
});

module.exports = app;