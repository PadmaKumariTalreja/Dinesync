const router = require('express').Router();
const adminid = require('../model/adminid.modal');

router.post("/registerid",async(req,res,next)=>{
    try{
        const {notificationid} = req.body;
        let n = "1"
        let d = await adminid.findOne({n})
        if(d && d.length > 0){
            await adminid.findOneAndUpdate({n:n},{$set:{notificationid:notificationid}})
            res.json({status:true});
        } else {
            const creteid = new adminid({n,notificationid});
            await creteid.save();
            res.json({status:true});
        }
    } catch (e){
        console.log(e)
        res.json({status:false});
    }
}
);

router.post("/getid",async(req,res,next)=>{
    try{
        let n = "1"
        let d = await adminid.findOne({n})
        res.json({data:d});
    } catch (e){
        console.log(e)
        res.json({status:false});
    }
});

module.exports = router;
