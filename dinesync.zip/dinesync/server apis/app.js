const express = require("express");
const bodyParser = require("body-parser")
const UserRoute = require("./routers/user.route");
const RestRoute = require("./routers/resturant.route");
const TableRoute = require("./routers/table.route");
const MenuRoute = require("./routers/menu.route");
const orderRoute = require("./routers/order.route");
const walletRoute = require("./routers/wallet.route");
const adminidRoute = require("./routers/adminid.route");
const complaintdRoute = require("./routers/complaint.route");
const chatdRoute = require("./routers/chat.route");

const app = express();
app.use(bodyParser.json());
app.use("/",UserRoute);
app.use("/",RestRoute);
app.use("/",TableRoute);
app.use("/",MenuRoute);
app.use("/",orderRoute);
app.use("/",walletRoute);
app.use("/",adminidRoute);
app.use("/",complaintdRoute);
app.use("/",chatdRoute);

module.exports = app;
