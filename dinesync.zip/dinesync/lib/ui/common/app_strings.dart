import 'package:dinesync/ui/common/app_colors.dart';
import 'package:flutter/material.dart';

const String ksHomeBottomSheetTitle = 'Build Great Apps!';
const String ksHomeBottomSheetDescription =
    'Stacked is built to help you build better apps. Give us a chance and we\'ll prove it to you. Check out stacked.filledstacks.com to learn more';

// fonts
const String poppins = 'poppins';
const String roboto = 'roboto';
const String montserrat = 'montserrat';

// icons
const String baseicons = "assets/";

List<String> cat = [
  "Chinees",
  "Mexican",
  "Italian",
  "American",
  "Korean",
  "Pakistani"
];

List<String> mcat = [
  "Appetizers",
  "Main Courses",
  "Burgers and Sandwiches",
  "Pizza",
  "Chicken",
  "Sides",
  "Desserts",
  "Beverages",
  "Breakfast Brunch",
  "Combo Meals",
  "Family Packs",
  "Customization"
];
