import 'package:flutter/material.dart';

const Color kcPrimaryColor = Color(0xFF3D0C11);
const Color kcPrimaryColorlight = Color(0xFFD80032);
const Color kcPrimaryColorVerylight = Color(0xFFF78CA2);
const Color kcPrimaryColorDark = Color(0xFF353A48);
const Color kcDarkGreyColor = Color(0xFF1A1B1E);
const Color kcMediumGrey = Color(0xFF474A54);
const Color kcLightGrey = Color.fromARGB(255, 187, 187, 187);
const Color kcVeryLightGrey = Color(0xFFE8E8E8);
const Color white = Colors.white;
const Color green = Colors.green;
const Color red = Colors.red;
const Color amber = Colors.amber;
const Color skin = Color(0xFFF9DEC9);
const Color kcBackgroundColor = kcDarkGreyColor;

Color getColorWithOpacity(Color colors, double val) {
  return colors.withOpacity(val);
}
