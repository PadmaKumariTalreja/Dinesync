// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:convert';
import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:jwt_decoder/jwt_decoder.dart';

import '../uihelper/snakbar_helper.dart';
import 'firebsaeuploadhelper.dart';

const url = 'http://10.0.2.2:3000/';
const registrationlink = "${url}register";
const loginlink = "${url}login";
const findonelink = "${url}findone";
const alluserlink = "${url}alluser";
const getoneuserlink = "${url}getoneuser";

// rest
const restregistrationlink = "${url}registerrest";
const getrestlink = "${url}checkrest";
const updaterestlink = "${url}updaterest";
const allrestlink = "${url}allrest";

// table
const registertablelink = "${url}registertable";
const alltablelink = "${url}alltable";
const updatetablelink = "${url}updatetable";
const deletetablelink = "${url}deletetable";

// menu
const registermenulink = "${url}registermenu";
const allmenulink = "${url}allmenu";
const updatedmenulink = "${url}updatedmenu";
const updatedmenuratinglink = "${url}updatedmenurating";
const deletemenulink = "${url}deletemenu";

// order
const registeroderlink = "${url}registeroder";
const getbyrestlink = "${url}getbyrest";
const getbyuserlink = "${url}getbyuser";
const restsalelink = "${url}restsale";
const updatestatuslink = "${url}updatestatus";

// wallet
const registerwalletlink = "${url}registerwallet";
const getwalletlink = "${url}getwallet";
const updatewalletlink = "${url}updatewallet";
const updatewallettopuplink = "${url}updatewallettopup";

// admin
const registeridlink = "${url}registerid";
const getidlink = "${url}getid";

// complaint
const registercomplaintlink = "${url}registercomplaint";
const allcomplaintlink = "${url}allcomplaint";

// chat
const registerchatlink = "${url}registerchat";
const allchatbyidlink = "${url}allchatbyid";
const addchatlink = "${url}addchat";
const allchatbydidlink = "${url}allchatbydid";

class ApiHelper {
  // chat
  static Future<Map> registerchat(String uid, String did) async {
    try {
      var response = await http.post(Uri.parse(registerchatlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "uid": uid,
            "did": did,
            "c": [],
            "date": DateTime.now().toString(),
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data;
    } catch (e) {
      return {};
    }
  }

  static Future<Map> allchatbyid(String id) async {
    try {
      var response = await http.post(Uri.parse(allchatbyidlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      print(data['data']);
      return data['data'];
    } catch (e) {
      return {};
    }
  }

  static Future<List> allchatbydid(String did) async {
    try {
      var response = await http.post(Uri.parse(allchatbydidlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"did": did}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      print(data['data']);
      return data['data'];
    } catch (e) {
      return [];
    }
  }

  static Future<bool> addchat(String id, Map dataa, String sendto) async {
    try {
      var response = await http.post(Uri.parse(addchatlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id, "data": dataa}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      Map d = await getoneuser(sendto);
      await FirebaseHelper.sendnotificationto(
          d['deviceid'], "New Message", dataa['mess']);
      return data['status'] as bool;
    } catch (e) {
      return false;
    }
  }

  static Future<Map> getoneuser(String id) async {
    try {
      var response = await http.post(Uri.parse(getoneuserlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id}));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      if (data['status']) {
        return data['data'] as Map;
      } else {
        return {};
      }
    } catch (e) {
      return {};
    }
  }

  // compliant
  static Future<bool> registercomplaint(
      String title, String des, BuildContext context) async {
    try {
      displayprogress(context);
      var response = await http.post(Uri.parse(registercomplaintlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "title": title,
            "des": des,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['message']);
      hideprogress(context);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'tryagainlater');
      return false;
    }
  }

  static Future<List> allcomplaint() async {
    try {
      var response = await http.post(
        Uri.parse(allcomplaintlink),
        headers: {"Content-Type": "application/json"},
      );
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['data'];
    } catch (e) {
      return [];
    }
  }

  // auth

  static Future<bool> registration(
      String name,
      String cnic,
      String number,
      String address,
      String dob,
      String img,
      String pass,
      String deviceid,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registrationlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "name": name,
            "cnic": cnic,
            "number": number,
            "address": address,
            "dob": dob,
            "img": img,
            "pass": pass,
            "deviceid": deviceid
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'tryagainlater');
      return false;
    }
  }

  static Future<Map> login(
      String number, String pass, String deviceid, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(loginlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(
              {"number": number, "pass": pass, "deviceid": deviceid}));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      if (data['status']) {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(data['token']);
        return decodedToken;
      } else {
        hideprogress(context);
        show_snackbar(context, data['message']);
        return {};
      }
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'tryagainlater');
      return {};
    }
  }

  static Future<Map> findone(String number, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(findonelink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"number": number}));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['data'];
    } catch (e) {
      return {};
    }
  }

  static Future<List> alluser(BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(alluserlink),
          headers: {"Content-Type": "application/json"});
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['data'] as List;
    } catch (e) {
      return [];
    }
  }

  static Future<bool> restregistration(
      String number,
      String name,
      String des,
      String mons,
      String mone,
      String tues,
      String tuee,
      String weds,
      String wede,
      String thus,
      String thue,
      String firs,
      String fire,
      String sats,
      String sate,
      String suns,
      String sune,
      List image,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(restregistrationlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "name": name,
            "number": number,
            "des": des,
            "mons": mons,
            "mone": mone,
            "tues": tues,
            "tuee": tuee,
            "weds": weds,
            "wede": wede,
            "thus": thus,
            "thue": thue,
            "firs": firs,
            "fire": fire,
            "sats": sats,
            "sate": sate,
            "suns": suns,
            "sune": sune,
            "image": image,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'tryagainlater');
      return false;
    }
  }

  static Future<Map> getrest(String number) async {
    try {
      var response = await http.post(Uri.parse(getrestlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"number": number}));
      return jsonDecode(utf8.decode(response.bodyBytes)) as Map;
    } catch (e) {
      return {};
    }
  }

  static Future<Map> allrest() async {
    try {
      var response = await http.post(
        Uri.parse(allrestlink),
        headers: {"Content-Type": "application/json"},
      );
      return jsonDecode(utf8.decode(response.bodyBytes)) as Map;
    } catch (e) {
      return {};
    }
  }

  static Future<bool> updateregistration(
      String number,
      String name,
      String des,
      String mons,
      String mone,
      String tues,
      String tuee,
      String weds,
      String wede,
      String thus,
      String thue,
      String firs,
      String fire,
      String sats,
      String sate,
      String suns,
      String sune,
      List image,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(updaterestlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "name": name,
            "number": number,
            "des": des,
            "mons": mons,
            "mone": mone,
            "tues": tues,
            "tuee": tuee,
            "weds": weds,
            "wede": wede,
            "thus": thus,
            "thue": thue,
            "firs": firs,
            "fire": fire,
            "sats": sats,
            "sate": sate,
            "suns": suns,
            "sune": sune,
            "image": image,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['message']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  // table
  static Future<bool> tableregistration(
      String number, String people, String des, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registertablelink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "number": number,
            "people": people,
            "des": des,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<List> getalltable(String number, String number2, String date,
      String times, String timee) async {
    try {
      var response = await http.post(Uri.parse(alltablelink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "number": number,
            "number2": number2,
            "date": date,
            "times": times,
            "timee": timee
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data['rest'] as List;
    } catch (e) {
      return [];
    }
  }

  static Future<bool> updatetable(
      String id, String people, String des, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(updatetablelink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "id": id,
            "people": people,
            "des": des,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['message']);
      return data['status'] as bool;
    } catch (e) {
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<bool> deletetable(String id, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(deletetablelink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "id": id,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['message']);
      return data['status'] as bool;
    } catch (e) {
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  // menu
  static Future<bool> menuregistration(
      String number,
      String itemname,
      String itemprice,
      String itemdes,
      List image,
      String cat,
      String mcat,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registermenulink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "itemname": itemname,
            "number": number,
            "itemprice": itemprice,
            "image": image,
            "itemdes": itemdes,
            'itemrating': '1',
            'itemuser': '1',
            'cat': cat,
            'mcat': mcat,
            "reviews": []
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<Map> getallmenu(String number, String mcat) async {
    try {
      var response = await http.post(Uri.parse(allmenulink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"number": number, "mcat": mcat}));
      var data = jsonDecode(utf8.decode(response.bodyBytes)) as Map;
      return data;
    } catch (e) {
      return {};
    }
  }

  static Future<bool> updatemenu(
      String id,
      String itemname,
      String itemprice,
      String itemdes,
      List image,
      String cat,
      String mcat,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(updatedmenulink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "itemname": itemname,
            "id": id,
            "itemprice": itemprice,
            "image": image,
            "itemdes": itemdes,
            'cat': cat,
            'mcat': mcat
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['message']);
      return data['status'] as bool;
    } catch (e) {
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<bool> updatedmenurating(
      String id, double itemrating, Map rdata, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(updatedmenuratinglink),
          headers: {"Content-Type": "application/json"},
          body:
              jsonEncode({"id": id, "itemrating": itemrating, "rdata": rdata}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['message']);
      return data['status'] as bool;
    } catch (e) {
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<bool> deletemenu(String id, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(deletemenulink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "id": id,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['message']);
      return data['status'] as bool;
    } catch (e) {
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  // order
  static Future<bool> ordergistration(
      String restnumber,
      String custnumber,
      String family,
      String table,
      List menu,
      String times,
      String timee,
      String datetime,
      String status,
      BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registeroderlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "restnumber": restnumber,
            "custnumber": custnumber,
            "family": family,
            "table": table,
            "menu": menu,
            'times': times,
            'timee': timee,
            'datetime': datetime,
            "status": status
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      log(e.toString());
      hideprogress(context);
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<bool> updatestatus(
      String id, String status, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(updatestatuslink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id, "status": status}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['status'] as bool;
    } catch (e) {
      show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<Map> getbyrest(String restnumber) async {
    try {
      var response = await http.post(Uri.parse(getbyrestlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"restnumber": restnumber}));
      return jsonDecode(utf8.decode(response.bodyBytes)) as Map;
    } catch (e) {
      return {};
    }
  }

  static Future<Map> restsale(String restnumber) async {
    try {
      var response = await http.post(Uri.parse(restsalelink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"restnumber": restnumber}));
      return jsonDecode(utf8.decode(response.bodyBytes)) as Map;
    } catch (e) {
      return {};
    }
  }

  static Future<Map> getbyuser(String custnumber) async {
    try {
      var response = await http.post(Uri.parse(getbyuserlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"custnumber": custnumber}));
      return jsonDecode(utf8.decode(response.bodyBytes)) as Map;
    } catch (e) {
      return {};
    }
  }

  // wallets
  static Future<bool> registerwallet(
      String number, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registerwalletlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "number": number,
            "notpay": "0",
            "paid": "0",
            "topup": "0",
            "cbill": "0"
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      // show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      hideprogress(context);
      // show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<Map> getwallet(String number) async {
    try {
      var response = await http.post(Uri.parse(getwalletlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"number": number}));
      return jsonDecode(utf8.decode(response.bodyBytes)) as Map;
    } catch (e) {
      return {};
    }
  }

  static Future<bool> updatewallet(String number, String notpay, String paid,
      String topup, String cbill, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(updatewalletlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "number": number,
            "notpay": notpay,
            "paid": paid,
            "topup": topup,
            "cbill": cbill
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['status'] as bool;
    } catch (e) {
      return false;
    }
  }

  static Future<bool> updatewallettopup(
      String number, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(updatewallettopuplink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"number": number}));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['status'] as bool;
    } catch (e) {
      return false;
    }
  }

  //admin
  static Future<bool> registerid(
      String notificationid, BuildContext context) async {
    try {
      var response = await http.post(Uri.parse(registeridlink),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "notificationid": notificationid,
          }));
      var data = jsonDecode(utf8.decode(response.bodyBytes));
      // show_snackbar(context, data['sucess']);
      return data['status'] as bool;
    } catch (e) {
      // show_snackbar(context, 'try again later');
      return false;
    }
  }

  static Future<Map> getid() async {
    try {
      var response = await http.post(Uri.parse(getidlink),
          headers: {"Content-Type": "application/json"});
      return jsonDecode(utf8.decode(response.bodyBytes)) as Map;
    } catch (e) {
      return {};
    }
  }
}
