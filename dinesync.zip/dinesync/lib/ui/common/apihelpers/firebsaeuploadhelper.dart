// ignore_for_file: depend_on_referenced_packages

import 'dart:convert';
import 'dart:io';
import 'package:dinesync/ui/common/apihelpers/apihelper.dart';
import 'package:path/path.dart' as path;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:http/http.dart' as http;

import '../../../app/app.locator.dart';
import '../../../services/fire_service.dart';

class FirebaseHelper {
  static Future<String> uploadFile(File? file, String phone) async {
    final fireService = locator<FireService>();

    String filename = path.basename(file!.path);
    String extension = path.extension(file.path);
    String randomChars = DateTime.now().millisecondsSinceEpoch.toString();
    String uniqueFilename = '$filename-$randomChars$extension';

    UploadTask uploadTask = fireService.storage
        .child('user')
        .child(phone)
        .child(uniqueFilename)
        .putFile(file);
    await uploadTask;
    String downloadURL = await fireService.storage
        .child('user')
        .child(phone)
        .child(uniqueFilename)
        .getDownloadURL();
    return downloadURL;
  }

  static Future<void> sendnotificationtoadmin(String title, String body) async {
    Map res = await ApiHelper.getid();
    await http.post(Uri.parse('https://fcm.googleapis.com/fcm/send'),
        body: jsonEncode({
          'to': res['data']['notificationid'],
          'priority': 'high',
          'notification': {'title': title, 'body': body}
        }),
        headers: {
          'Content-Type': 'application/json',
          'Authorization':
              'key=AAAARMLasE8:APA91bFXprNF7pCGQ21OeBvzr7n0HcbPa7wO8U_-ISqZQLWJK8hFQDhw-W3S3W8-anNvHjUy9FbCob_8VAPJ5katq6YYzSIccIiFxABbUNdUi2dQbZrjuS5xT6icvf1fpiRTCx4zc8lN'
        });
  }

  static Future<void> sendnotificationto(
      String notificationid, String title, String body) async {
    String keys =
        'AAAARMLasE8:APA91bFXprNF7pCGQ21OeBvzr7n0HcbPa7wO8U_-ISqZQLWJK8hFQDhw-W3S3W8-anNvHjUy9FbCob_8VAPJ5katq6YYzSIccIiFxABbUNdUi2dQbZrjuS5xT6icvf1fpiRTCx4zc8lN';
    await http.post(Uri.parse('https://fcm.googleapis.com/fcm/send'),
        body: jsonEncode({
          'to': notificationid,
          'priority': 'high',
          'notification': {'title': title, 'body': body}
        }),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'key=$keys'
        });
  }
}
