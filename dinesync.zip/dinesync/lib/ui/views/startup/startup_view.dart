import 'package:dinesync/ui/common/app_strings.dart';
import 'package:dinesync/ui/common/uihelper/text_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';
import 'package:dinesync/ui/common/ui_helpers.dart';

import '../../common/app_colors.dart';
import 'startup_viewmodel.dart';

class StartupView extends StackedView<StartupViewModel> {
  const StartupView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    StartupViewModel viewModel,
    Widget? child,
  ) {
    viewModel.runStartupLogic(context);
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
                child: Opacity(
              opacity: 0.3,
              child: Image.asset(
                'assets/splash screen.jpg',
                width: screenWidth(context),
                height: screenHeight(context),
                fit: BoxFit.cover,
              ),
            )),
            Positioned(
              bottom: 0,
              child: Container(
                width: screenWidth(context),
                height: screenHeightCustom(context, 0.45),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [white, getColorWithOpacity(white, 0)],
                )),
              ),
            ),
            Positioned(
                bottom: screenHeightCustom(context, 0.1),
                left: 0,
                right: 0,
                child: Column(
                  children: [
                    SizedBox(
                        width: screenWidthCustom(context, 0.3),
                        height: screenWidthCustom(context, 0.3),
                        child: Lottie.asset('assets/loading.json')),
                    text_helper(
                      data: "DineSync ",
                      font: montserrat,
                      color: kcDarkGreyColor,
                      size: fontSize28,
                      bold: true,
                    ),
                  ],
                ))
          ],
        ),
      ),
    );
  }

  @override
  StartupViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      StartupViewModel();
}
