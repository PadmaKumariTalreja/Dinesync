import 'package:dinesync/ui/views/login/login_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:stacked/stacked.dart';
import 'package:dinesync/app/app.locator.dart';
import 'package:dinesync/app/app.router.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../services/sharedpref_service.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../home/home_view.dart';
import '../resturantowner/resturantowner_view.dart';

class StartupViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();

  Future runStartupLogic(BuildContext context) async {
    _sharedpref.initialize();
    hideStatusBar();
    await Future.delayed(const Duration(seconds: 3));
    showStatusBar();
    if (_sharedpref.contains('auth') &&
        _sharedpref.readString('auth') == 't' &&
        _sharedpref.contains('number')) {
      if (await fingerauth(context)) {
        try {
          final bool result = await localAuth.authenticate(
              localizedReason: 'Please authenticate to show account balance',
              options: const AuthenticationOptions(useErrorDialogs: false));
          if (result) {
            if (_sharedpref.readString('number') != '0000-0000000') {
              _navigationService.clearStackAndShow(Routes.homeView);
              _navigationService.replaceWithTransition(const HomeView(),
                  routeName: Routes.homeView,
                  transitionStyle: Transition.rightToLeft);
            } else {
              _navigationService.clearStackAndShow(Routes.resturantownerView);
              _navigationService.replaceWithTransition(
                  const ResturantownerView(),
                  routeName: Routes.resturantownerView,
                  transitionStyle: Transition.rightToLeft);
            }
          } else {
            _navigationService.replaceWithTransition(const LoginView(),
                routeName: Routes.loginView,
                transitionStyle: Transition.rightToLeft);
          }
        } catch (e) {
          _navigationService.replaceWithTransition(const LoginView(),
              routeName: Routes.loginView,
              transitionStyle: Transition.rightToLeft);
        }
      } else {
        show_snackbar(context, "Your do not have finger print");
        _navigationService.replaceWithTransition(const LoginView(),
            routeName: Routes.loginView,
            transitionStyle: Transition.rightToLeft);
      }
    } else {
      _navigationService.replaceWithTransition(const LoginView(),
          routeName: Routes.loginView, transitionStyle: Transition.rightToLeft);
    }
  }

  final localAuth = LocalAuthentication();
  Future<bool> fingerauth(BuildContext context) async {
    try {
      bool canCheckBiometrics = await localAuth.canCheckBiometrics;
      if (canCheckBiometrics) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      show_snackbar(context, e.toString());
      return false;
    }
  }

  void hideStatusBar() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
  }

  void showStatusBar() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
        overlays: SystemUiOverlay.values);
    notifyListeners();
  }
}
