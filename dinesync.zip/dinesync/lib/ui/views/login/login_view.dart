import 'package:dinesync/ui/common/app_strings.dart';
import 'package:dinesync/ui/common/ui_helpers.dart';
import 'package:dinesync/ui/common/uihelper/button_helper.dart';
import 'package:dinesync/ui/common/uihelper/text_helper.dart';
import 'package:dinesync/ui/common/uihelper/text_veiw_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../common/app_colors.dart';
import 'login_viewmodel.dart';

class LoginView extends StackedView<LoginViewModel> {
  const LoginView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    LoginViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      text_helper(
                        data: "Welcome",
                        font: poppins,
                        color: kcPrimaryColor,
                        size: fontSize22,
                        bold: true,
                      ),
                      SizedBox(
                          width: screenWidthCustom(context, 0.2),
                          height: screenWidthCustom(context, 0.2),
                          child: Lottie.asset('assets/loading.json')),
                      text_helper(
                        data: "DineSync",
                        font: poppins,
                        color: kcPrimaryColorlight,
                        size: fontSize22,
                        bold: true,
                      ),
                    ],
                  ).animate(delay: 500.milliseconds).fade(),
                  text_helper(
                          data: "One step away to relax your hunger",
                          font: poppins,
                          color: kcDarkGreyColor,
                          size: fontSize14)
                      .animate(delay: 700.milliseconds)
                      .fade()
                      .moveY(begin: 50, end: 0)
                ],
              ),
              verticalSpaceSmall,
              Padding(
                padding: const EdgeInsets.all(18.0),
                child: Column(
                  children: [
                    text_view_helper(
                      hint: "Enter Phone Number",
                      controller: viewModel.phone,
                      showicon: true,
                      maxlength: 11,
                      formatter: [
                        FilteringTextInputFormatter.allow(getRegExpint())
                      ],
                      textInputType: TextInputType.phone,
                      icon: const Icon(Icons.call),
                    )
                        .animate(delay: 900.milliseconds)
                        .fade()
                        .moveY(begin: 50, end: 0),
                    text_view_helper(
                      hint: "Enter Password",
                      controller: viewModel.pass,
                      obsecure: true,
                      showicon: true,
                      icon: const Icon(Icons.password),
                    )
                        .animate(delay: 1100.milliseconds)
                        .fade()
                        .moveY(begin: 50, end: 0),
                  ],
                ),
              ),
              button_helper(
                      onpress: () => viewModel.login(context),
                      color: kcPrimaryColorlight,
                      width: screenHeightCustom(context, 0.2),
                      child: text_helper(
                        data: "Login",
                        font: poppins,
                        color: white,
                        size: fontSize18,
                        bold: true,
                      ))
                  .animate(delay: 1300.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
              InkWell(
                onTap: () => viewModel.signup(),
                child: text_helper(
                  data: "Do not have Account",
                  font: poppins,
                  color: kcDarkGreyColor,
                  size: fontSize12,
                ),
              )
                  .animate(delay: 1500.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void onViewModelReady(LoginViewModel viewModel) {
    permission();
  }

  Future<void> permission() async {
    await Permission.notification.request();
  }

  @override
  void onDispose(LoginViewModel viewModel) {
    viewModel.pass.dispose();
    viewModel.phone.dispose();
  }

  @override
  LoginViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      LoginViewModel();
}
