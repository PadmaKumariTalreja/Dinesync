import 'package:dinesync/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:dinesync/ui/common/uihelper/snakbar_helper.dart';
import 'package:dinesync/ui/views/details/details_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/fire_service.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/apihelpers/apihelper.dart';
import '../home/home_view.dart';
import '../resturantowner/resturantowner_view.dart';

class LoginViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();
  final _fireService = locator<FireService>();

  TextEditingController phone = MaskedTextController(mask: '0000-0000000');
  TextEditingController pass = TextEditingController();

  Future<void> login(BuildContext context) async {
    if (phone.text.isEmpty || pass.text.isEmpty) {
      show_snackbar(context, "fill all fields");
    } else if (phone.text.length != 12) {
      show_snackbar(context, "Number is not correct");
    } else if (phone.text == '0000-0000000' && pass.text == 'admin') {
      // displayprogress(context);
      if (!_sharedpref.contains('adminw')) {
        await ApiHelper.registerwallet(phone.text, context);
        _sharedpref.setString('adminw', '1');
      }
      _fireService.messaging.getToken().then((value) async => {
            await ApiHelper.registerid(value.toString(), context),
            _sharedpref.setString('deviceid', value.toString()),
            await FirebaseHelper.sendnotificationto(
                value.toString(), "Admin", "Welcome Admin"),
          });
      // hideprogress(context);
      _sharedpref.setString('number', '0000-0000000');
      _sharedpref.setString('auth', 't');
      _navigationService.clearStackAndShow(Routes.resturantownerView);
      _navigationService.replaceWithTransition(const ResturantownerView(),
          routeName: Routes.resturantownerView,
          transitionStyle: Transition.rightToLeft);
    } else {
      displayprogress(context);
      var result = _fireService.messaging.getToken().then((value) {
        return ApiHelper.login(
            phone.text, pass.text, value.toString(), context);
      });
      result.then((value) async {
        _sharedpref.setString('name', value['name']);
        _sharedpref.setString('cnic', value['cnic']);
        _sharedpref.setString('number', phone.text);
        _sharedpref.setString('address', value['address']);
        _sharedpref.setString('dob', value['dob']);
        _sharedpref.setString('img', value['img']);
        _sharedpref.setString('deviceid', value['deviceid']);
        await FirebaseHelper.sendnotificationto(
            value['deviceid'], "login Sucessfully", "Welcome ${value['name']}");
        hideprogress(context);
        _sharedpref.setString('auth', 't');
        _navigationService.clearStackAndShow(Routes.homeView);
        _navigationService.replaceWithTransition(const HomeView(),
            routeName: Routes.homeView,
            transitionStyle: Transition.rightToLeft);
      });
    }
  }

  void signup() {
    _navigationService.replaceWithTransition(const DetailsView(),
        routeName: Routes.detailsView, transitionStyle: Transition.rightToLeft);
  }
}
