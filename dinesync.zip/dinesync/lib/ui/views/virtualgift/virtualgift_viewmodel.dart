import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';

class VirtualgiftViewModel extends BaseViewModel {
  TextEditingController search = TextEditingController();
}
