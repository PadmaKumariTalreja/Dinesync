// ignore_for_file: use_build_context_synchronously

import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../services/sharedpref_service.dart';

class ResturantmenuViewModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();

  bool check = true;
  String smcat = '';
}
