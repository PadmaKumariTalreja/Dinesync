import 'package:animated_rating_stars/animated_rating_stars.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dinesync/ui/common/app_colors.dart';
import 'package:dinesync/ui/common/app_strings.dart';
import 'package:dinesync/ui/widgets/common/addmenu/addmenu.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_helper.dart';
import 'resturantmenu_viewmodel.dart';

class ResturantmenuView extends StackedView<ResturantmenuViewModel> {
  const ResturantmenuView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    ResturantmenuViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: screenWidth(context),
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.fromLTRB(20, 15, 20, 15),
              decoration: BoxDecoration(color: white, boxShadow: [
                BoxShadow(
                    offset: const Offset(2, 2),
                    spreadRadius: 2,
                    blurRadius: 2,
                    color: getColorWithOpacity(kcLightGrey, 0.2))
              ]),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  InkWell(
                    onTap: () {
                      if (viewModel.smcat == '') {
                        Navigator.pop(context);
                      } else {
                        viewModel.smcat = '';
                        viewModel.notifyListeners();
                      }
                    },
                    child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50),
                            color: getColorWithOpacity(kcLightGrey, 0.2)),
                        child: const Icon(
                          Icons.arrow_back,
                          size: 30,
                        )),
                  ),
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          'assets/menu2.png',
                          height: screenHeightCustom(context, 0.08),
                          width: screenWidthCustom(context, 0.08),
                        ),
                        horizontalSpaceSmall,
                        text_helper(
                            data: "Menu",
                            font: poppins,
                            bold: true,
                            color: kcDarkGreyColor,
                            size: fontSize14)
                      ],
                    ),
                  ),
                  viewModel.smcat == ''
                      ? InkWell(
                          onTap: () {
                            viewModel.check = !viewModel.check;
                            viewModel.notifyListeners();
                          },
                          child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(50),
                                  color: getColorWithOpacity(kcLightGrey, 0.2)),
                              child: Icon(
                                !viewModel.check
                                    ? Icons.grid_4x4
                                    : Icons.list_outlined,
                                size: 30,
                              )))
                      : InkWell(
                          onTap: () {
                            viewModel.notifyListeners();
                          },
                          child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(50),
                                  color: getColorWithOpacity(kcLightGrey, 0.2)),
                              child: const Icon(
                                Icons.refresh,
                                size: 30,
                              )),
                        ),
                ],
              ),
            ),
            viewModel.smcat == ''
                ? Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: viewModel.check
                          ? GridView.builder(
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 3,
                                      crossAxisSpacing: 10,
                                      mainAxisSpacing: 10),
                              itemCount: mcat.length, // Example item count
                              itemBuilder: (BuildContext context, int index) {
                                return InkWell(
                                  onTap: () {
                                    viewModel.smcat = mcat[index];
                                    viewModel.notifyListeners();
                                  },
                                  child: Container(
                                      padding: const EdgeInsets.all(5),
                                      decoration: BoxDecoration(
                                        color: white,
                                        boxShadow: [
                                          BoxShadow(
                                              offset: const Offset(3, 3),
                                              spreadRadius: 1,
                                              blurRadius: 1,
                                              color: getColorWithOpacity(
                                                  kcLightGrey, 0.4)),
                                        ],
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Image.asset(
                                            'assets/dish.png',
                                            width:
                                                screenWidthCustom(context, 0.1),
                                            height: screenHeightCustom(
                                                context, 0.07),
                                          ),
                                          text_helper(
                                              data: mcat[index],
                                              font: poppins,
                                              bold: true,
                                              color: kcPrimaryColorDark,
                                              size: fontSize10),
                                        ],
                                      )),
                                );
                              },
                            )
                          : ListView.builder(
                              itemCount: mcat.length,
                              itemBuilder: (BuildContext context, int index) {
                                return InkWell(
                                  onTap: () {
                                    viewModel.smcat = mcat[index];
                                    viewModel.notifyListeners();
                                  },
                                  child: Container(
                                      padding: const EdgeInsets.all(5),
                                      margin: const EdgeInsets.all(10),
                                      decoration: BoxDecoration(
                                        color: white,
                                        boxShadow: [
                                          BoxShadow(
                                              offset: const Offset(3, 3),
                                              spreadRadius: 1,
                                              blurRadius: 1,
                                              color: getColorWithOpacity(
                                                  kcLightGrey, 0.4)),
                                        ],
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Image.asset(
                                            'assets/dish.png',
                                            width:
                                                screenWidthCustom(context, 0.1),
                                            height: screenHeightCustom(
                                                context, 0.07),
                                          ),
                                          horizontalSpaceSmall,
                                          text_helper(
                                              data: mcat[index],
                                              font: poppins,
                                              bold: true,
                                              color: kcPrimaryColorDark,
                                              size: fontSize10),
                                        ],
                                      )),
                                );
                              },
                            ),
                    ),
                  )
                : Expanded(
                    child: FutureBuilder(
                      future: ApiHelper.getallmenu(
                          viewModel.sharedpref.readString('number'),
                          viewModel.smcat),
                      builder: (BuildContext context, AsyncSnapshot snapshot) {
                        if (snapshot.hasData) {
                          if (snapshot.data!['rest'].toString() == '[]') {
                            return Center(
                              child: text_helper(
                                  data: "No Data",
                                  font: poppins,
                                  bold: true,
                                  color: kcPrimaryColor,
                                  size: fontSize14),
                            );
                          } else {
                            return ListView(
                              children: List.of(snapshot.data!['rest'])
                                  .map((e) => InkWell(
                                        onTap: () => menusheet(context, e),
                                        child: Container(
                                          padding: const EdgeInsets.all(10),
                                          margin: const EdgeInsets.all(10),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              boxShadow: [
                                                BoxShadow(
                                                    offset: const Offset(2, 2),
                                                    spreadRadius: 2,
                                                    blurRadius: 2,
                                                    color: getColorWithOpacity(
                                                        kcLightGrey, 0.2))
                                              ],
                                              color: white),
                                          child: Column(
                                            children: [
                                              List.of(e['image']).isEmpty
                                                  ? const SizedBox.shrink()
                                                  : SizedBox(
                                                      width:
                                                          screenWidth(context),
                                                      height:
                                                          screenHeightCustom(
                                                              context, 0.2),
                                                      child: ListView(
                                                        scrollDirection:
                                                            Axis.horizontal,
                                                        children:
                                                            List.of(e['image'])
                                                                .map((e) =>
                                                                    Container(
                                                                      decoration: BoxDecoration(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          boxShadow: [
                                                                            BoxShadow(
                                                                                offset: const Offset(2, 2),
                                                                                spreadRadius: 2,
                                                                                blurRadius: 2,
                                                                                color: getColorWithOpacity(kcLightGrey, 0.2))
                                                                          ],
                                                                          color: white),
                                                                      margin: const EdgeInsets
                                                                          .all(
                                                                          8.0),
                                                                      child:
                                                                          ClipRRect(
                                                                        borderRadius:
                                                                            BorderRadius.circular(10),
                                                                        child:
                                                                            CachedNetworkImage(
                                                                          imageUrl:
                                                                              e,
                                                                          imageBuilder: (context, imageProvider) =>
                                                                              Container(
                                                                            width:
                                                                                screenWidthCustom(context, 0.25),
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              image: DecorationImage(
                                                                                image: imageProvider,
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          placeholder: (context, url) =>
                                                                              displaysimpleprogress(context),
                                                                          errorWidget: (context, url, error) =>
                                                                              const Icon(
                                                                            Icons.error,
                                                                            color:
                                                                                white,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ))
                                                                .toList(),
                                                      ),
                                                    ),
                                              rowdata("Item Name :  ",
                                                  e['itemname'], Icons.numbers),
                                              rowdata("Main Category :  ",
                                                  e['cat'], Icons.category),
                                              rowdata("Category :  ", e['mcat'],
                                                  Icons.category),
                                              rowdata(
                                                  "Price :  ",
                                                  e['itemprice'],
                                                  Icons.numbers),
                                              rowdata("Description :  ",
                                                  e['itemdes'], Icons.numbers),
                                              AnimatedRatingStars(
                                                initialRating: int.parse(
                                                        e['itemrating']) /
                                                    int.parse(e['itemuser']),
                                                minRating: 0.0,
                                                maxRating: 5.0,
                                                filledColor: Colors.amber,
                                                emptyColor: Colors.grey,
                                                filledIcon: Icons.star,
                                                halfFilledIcon: Icons.star_half,
                                                emptyIcon: Icons.star_border,
                                                onChanged: (double rating) {},
                                                displayRatingValue: true,
                                                interactiveTooltips: true,
                                                customFilledIcon: Icons.star,
                                                customHalfFilledIcon:
                                                    Icons.star_half,
                                                customEmptyIcon:
                                                    Icons.star_border,
                                                starSize: 20,
                                                animationDuration:
                                                    const Duration(
                                                        milliseconds: 300),
                                                animationCurve:
                                                    Curves.easeInOut,
                                                readOnly: true,
                                              )
                                            ],
                                          ),
                                        )
                                            .animate(delay: 500.milliseconds)
                                            .fade()
                                            .moveY(begin: 50, end: 0),
                                      ))
                                  .toList(),
                            );
                          }
                        } else if (snapshot.hasError) {
                          return const Icon(Icons.error, color: kcPrimaryColor);
                        } else {
                          return displaysimpleprogress(context);
                        }
                      },
                    ),
                  )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => menusheet(context, {}),
        backgroundColor: kcPrimaryColor,
        child: const Icon(
          Icons.add,
          color: white,
        ),
      ),
    );
  }

  void menusheet(BuildContext context, Map data) {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return Addmenu(update: data);
        });
  }

  Widget rowdata(String title, String des, IconData iconData) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          iconData,
          color: kcPrimaryColor,
        ),
        text_helper(
          data: title,
          font: poppins,
          color: kcPrimaryColor,
          size: fontSize14,
          bold: true,
        ),
        Expanded(
          child: text_helper(
              data: des,
              font: poppins,
              textAlign: TextAlign.start,
              color: kcDarkGreyColor,
              size: fontSize12),
        ),
      ],
    );
  }

  @override
  ResturantmenuViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      ResturantmenuViewModel();
}
