import 'package:dinesync/ui/common/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_helper.dart';
import 'pic_viewmodel.dart';

class PicView extends StackedView<PicViewModel> {
  const PicView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    PicViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  text_helper(
                    data: "Add your pic",
                    font: poppins,
                    color: kcPrimaryColor,
                    size: fontSize22,
                    bold: true,
                  ),
                  SizedBox(
                      width: screenWidthCustom(context, 0.2),
                      height: screenWidthCustom(context, 0.2),
                      child: Lottie.asset('assets/loading.json')),
                ],
              )
                  .animate(delay: 500.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
              verticalSpaceSmall,
              viewModel.image == null
                  ? InkWell(
                      onTap: () => viewModel.pic(),
                      child: Icon(
                        Icons.person,
                        size: screenWidthCustom(context, 0.5),
                      ),
                    )
                      .animate(delay: 700.milliseconds)
                      .fade()
                      .moveY(begin: 50, end: 0)
                  : InkWell(
                      onTap: () => viewModel.pic(),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.file(
                            viewModel.image!,
                            fit: BoxFit.cover,
                            width: screenWidth(context),
                            height: screenWidth(context),
                          ).animate(delay: 500.milliseconds).fade(),
                        ),
                      ),
                    ),
              button_helper(
                      onpress: () => viewModel.next(context),
                      color: kcPrimaryColorlight,
                      width: screenWidthCustom(context, 0.3),
                      padding: const EdgeInsetsDirectional.all(8),
                      child: text_helper(
                        data: "next",
                        font: poppins,
                        color: white,
                        size: fontSize18,
                        bold: true,
                      ))
                  .animate(delay: 900.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
            ],
          ),
        ),
      ),
    );
  }

  @override
  PicViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      PicViewModel();
}
