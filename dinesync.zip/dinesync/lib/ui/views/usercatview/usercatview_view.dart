import 'package:animated_rating_stars/animated_rating_stars.dart';
import 'package:flutter/material.dart';
import 'package:outline_search_bar/outline_search_bar.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/app_colors.dart';
import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../widgets/common/customslider/customslider.dart';
import 'usercatview_viewmodel.dart';

class UsercatviewView extends StackedView<UsercatviewViewModel> {
  UsercatviewView({Key? key, required this.cat}) : super(key: key);
  String cat;

  @override
  Widget builder(
    BuildContext context,
    UsercatviewViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        appBar: AppBar(
          backgroundColor: kcPrimaryColor,
          iconTheme: const IconThemeData(color: white),
          title: text_helper(
              data: "User Category",
              font: poppins,
              bold: true,
              color: white,
              size: fontSize14),
        ),
        body: SafeArea(
            child: Column(
          children: [
            OutlineSearchBar(
              margin: const EdgeInsets.fromLTRB(10, 8, 10, 0),
              backgroundColor: white,
              borderRadius: BorderRadius.circular(10),
              borderColor: kcLightGrey,
              borderWidth: 2,
              cursorColor: kcPrimaryColorlight,
              clearButtonColor: kcPrimaryColorlight,
              clearButtonIconColor: white,
              hintText: "Are you hungry !!",
              ignoreSpecialChar: true,
              searchButtonIconColor: kcPrimaryColorlight,
              hintStyle: text_helper.customstyle(
                  poppins, kcLightGrey, fontSize12, context, false),
              textStyle: text_helper.customstyle(
                  poppins, kcPrimaryColorlight, fontSize12, context, true),
              textEditingController: viewModel.search,
              onKeywordChanged: (String val) {
                viewModel.notifyListeners();
              },
            ),
            Expanded(
              child: FutureBuilder(
                future: ApiHelper.getallmenu('0000-0000000', ''),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                      itemCount: snapshot.data!['rest'].length,
                      itemBuilder: (BuildContext context, int index) {
                        if (cat == snapshot.data!['rest'][index]['cat']) {
                          if (viewModel.search.text.isEmpty) {
                            return listdata(snapshot.data!['rest'][index],
                                viewModel, context);
                          } else {
                            if (snapshot.data!['rest'][index]['itemname']
                                .toString()
                                .toLowerCase()
                                .contains(
                                    viewModel.search.text.toLowerCase())) {
                              return listdata(snapshot.data!['rest'][index],
                                  viewModel, context);
                            } else {
                              return const SizedBox.shrink();
                            }
                          }
                        } else {
                          return const SizedBox.shrink();
                        }
                      },
                    );
                  } else if (snapshot.hasError) {
                    return const Icon(
                      Icons.error,
                      color: kcPrimaryColor,
                    );
                  } else {
                    return displaysimpleprogress(context);
                  }
                },
              ),
            ),
          ],
        )));
  }

  Widget listdata(Map e, UsercatviewViewModel viewModel, BuildContext context) {
    return Container(
      width: screenWidth(context),
      height: 200,
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      child: Column(
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            text_helper(
                                data: e['cat'],
                                font: poppins,
                                color: kcPrimaryColorlight,
                                size: fontSize12),
                            text_helper(
                                data: e['itemname'],
                                bold: true,
                                font: poppins,
                                color: kcDarkGreyColor,
                                size: fontSize14),
                            text_helper(
                              data: e['itemdes'],
                              textAlign: TextAlign.start,
                              font: poppins,
                              color: kcDarkGreyColor,
                              size: fontSize10,
                            ),
                          ],
                        ),
                      ),
                      text_helper(
                          data: 'starting from ' + e['itemprice'],
                          font: poppins,
                          color: kcDarkGreyColor,
                          size: fontSize12),
                      AnimatedRatingStars(
                        initialRating: int.parse(e['itemrating']) /
                            int.parse(e['itemuser']),
                        minRating: 0.0,
                        maxRating: 5.0,
                        filledColor: Colors.amber,
                        emptyColor: Colors.grey,
                        filledIcon: Icons.star,
                        halfFilledIcon: Icons.star_half,
                        emptyIcon: Icons.star_border,
                        onChanged: (double rating) {},
                        displayRatingValue: true,
                        interactiveTooltips: true,
                        customFilledIcon: Icons.star,
                        customHalfFilledIcon: Icons.star_half,
                        customEmptyIcon: Icons.star_border,
                        starSize: 20,
                        animationDuration: const Duration(milliseconds: 300),
                        animationCurve: Curves.easeInOut,
                        readOnly: true,
                      ),
                    ],
                  ),
                ),
                SizedBox(
                    width: screenWidthCustom(context, 0.4),
                    child: Customslider(data: e['image'])),
              ],
            ),
          ),
          verticalSpaceSmall,
          Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: () => viewModel.next(),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: kcPrimaryColor,
                    ),
                    child: text_helper(
                        data: "Order Now",
                        font: poppins,
                        color: white,
                        size: fontSize14,
                        bold: true),
                  ),
                ),
              ),
              horizontalSpaceTiny,
              Expanded(
                child: InkWell(
                  onTap: () => viewModel.reviws(e),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: kcPrimaryColor,
                    ),
                    child: text_helper(
                        data: "Check Reviews",
                        font: poppins,
                        color: white,
                        size: fontSize14,
                        bold: true),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  @override
  UsercatviewViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      UsercatviewViewModel();
}
