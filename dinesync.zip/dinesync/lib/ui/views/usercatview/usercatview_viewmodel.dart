import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../resturanttable/resturanttable_view.dart';
import '../reviews/reviews_view.dart';

class UsercatviewViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  TextEditingController search = TextEditingController();

  void reviws(Map data) {
    _navigationService.navigateWithTransition(ReviewsView(data: data),
        routeName: Routes.reviewsView, transitionStyle: Transition.rightToLeft);
  }

  void next() {
    _navigationService.navigateWithTransition(
        ResturanttableView(
          user: true,
        ),
        routeName: Routes.resturanttableView,
        transitionStyle: Transition.rightToLeft);
  }
}
