import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../services/sharedpref_service.dart';
import '../wallet/wallet_viewmodel.dart';

class AnalyticsViewModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();

  double max = 0;
  final List<ChartData> histogramData = <ChartData>[];
  void populate(Map data) {
    max = 0;
    data.forEach((key, value) {
      histogramData
          .add(ChartData(key.toString(), double.parse(value.toString())));
      max += value;
    });
  }

  TextEditingController coast = TextEditingController();
  TextEditingController selling = TextEditingController();
  TextEditingController profit = TextEditingController();

  void calculate() {
    profit.text = "${int.parse(selling.text) - int.parse(coast.text)}";
    notifyListeners();
  }
}
