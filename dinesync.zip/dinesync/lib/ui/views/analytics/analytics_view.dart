import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/app_colors.dart';
import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../common/uihelper/text_veiw_helper.dart';
import '../wallet/wallet_viewmodel.dart';
import 'analytics_viewmodel.dart';

class AnalyticsView extends StackedView<AnalyticsViewModel> {
  const AnalyticsView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    AnalyticsViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        appBar: AppBar(
          backgroundColor: white,
          title: text_helper(
              data: "Analytics",
              font: montserrat,
              color: kcDarkGreyColor,
              size: fontSize14,
              bold: true),
        ),
        body: SafeArea(
          child: ListView(
            children: [
              FutureBuilder(
                future: ApiHelper.restsale(
                    viewModel.sharedpref.readString('number')),
                builder: (BuildContext context,
                    AsyncSnapshot<Map<dynamic, dynamic>> snapshot) {
                  if (snapshot.hasData) {
                    viewModel.populate(snapshot.data!['rest']);
                    return Column(
                      children: [
                        Row(
                          children: [
                            sales(
                                "Total Sale",
                                snapshot.data!['rest'].toString() == "{}"
                                    ? "0"
                                    : double.parse(snapshot.data!['rest'].length
                                            .toString())
                                        .toStringAsFixed(2)),
                            sales("Total Revenue", viewModel.max.toString()),
                          ],
                        ),
                        Row(
                          children: [
                            sales(
                                "Average Order Value",
                                (viewModel.max / snapshot.data!['rest'].length)
                                            .toString() ==
                                        "NaN"
                                    ? "0"
                                    : double.parse((viewModel.max /
                                                snapshot.data!['rest'].length)
                                            .toString())
                                        .toStringAsFixed(2)),
                            FutureBuilder(
                              future: ApiHelper.getbyrest(
                                  viewModel.sharedpref.readString('number')),
                              builder: (BuildContext context,
                                  AsyncSnapshot<Map<dynamic, dynamic>>
                                      snapshot) {
                                if (snapshot.hasData) {
                                  return sales(
                                      "Total Orders",
                                      double.parse(snapshot.data!['rest'].length
                                              .toString())
                                          .toStringAsFixed(2));
                                } else if (snapshot.hasError) {
                                  return const Icon(
                                    Icons.error,
                                    color: kcDarkGreyColor,
                                  );
                                } else {
                                  return displaysimpleprogress(context);
                                }
                              },
                            ),
                          ],
                        ),
                        SfCartesianChart(
                            primaryXAxis: CategoryAxis(),
                            borderWidth: 4,
                            plotAreaBorderWidth: 0,
                            title: ChartTitle(
                                text: "Sale Details",
                                textStyle: text_helper.customstyle(
                                    poppins,
                                    kcDarkGreyColor,
                                    fontSize12,
                                    context,
                                    true)),
                            primaryYAxis: NumericAxis(
                                minimum: 0,
                                maximum: viewModel.max,
                                interval: 100),
                            tooltipBehavior: TooltipBehavior(enable: true),
                            series: <ChartSeries<ChartData, String>>[
                              ColumnSeries<ChartData, String>(
                                  dataSource: viewModel.histogramData,
                                  xValueMapper: (ChartData data, _) => data.x,
                                  yValueMapper: (ChartData data, _) => data.y,
                                  name: '',
                                  color: getColorWithOpacity(skin, 0.7))
                            ]),
                      ],
                    );
                  } else if (snapshot.hasError) {
                    return const Icon(
                      Icons.error,
                      color: kcDarkGreyColor,
                    );
                  } else {
                    return displaysimpleprogress(context);
                  }
                },
              ),
              Container(
                width: screenWidth(context),
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: getColorWithOpacity(skin, 0.1)),
                child: Column(
                  children: [
                    text_helper(
                        data: "Profit Loss Calculator",
                        font: poppins,
                        bold: true,
                        color: kcDarkGreyColor,
                        size: fontSize12),
                    text_view_helper(
                        hint: "Enter Coast", controller: viewModel.coast),
                    text_view_helper(
                        hint: "Enter Selling price",
                        controller: viewModel.selling),
                    viewModel.profit.text.isEmpty
                        ? const SizedBox.shrink()
                        : text_helper(
                            data: "Profile is : ${viewModel.profit.text}",
                            font: montserrat,
                            color: kcPrimaryColor,
                            size: fontSize16,
                            bold: true,
                          ),
                    button_helper(
                        onpress: () => viewModel.calculate(),
                        color: kcPrimaryColor,
                        width: screenWidthCustom(context, 0.3),
                        child: text_helper(
                            data: "Calculate",
                            font: poppins,
                            color: white,
                            size: fontSize12))
                  ],
                ),
              )
            ],
          ),
        ));
  }

  Widget sales(String title, String des) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        margin: const EdgeInsets.fromLTRB(10, 5, 10, 5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: getColorWithOpacity(skin, 0.2)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(
              Icons.bar_chart,
              color: kcPrimaryColor,
            ),
            horizontalSpaceSmall,
            text_helper(
                data: title,
                font: poppins,
                bold: true,
                color: kcPrimaryColor,
                size: fontSize14),
            text_helper(
                data: des,
                font: poppins,
                color: kcPrimaryColor,
                size: fontSize14)
          ],
        ),
      ),
    );
  }

  @override
  AnalyticsViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      AnalyticsViewModel();
}
