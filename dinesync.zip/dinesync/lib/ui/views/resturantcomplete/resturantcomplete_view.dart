import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dinesync/ui/common/apihelpers/apihelper.dart';
import 'package:dinesync/ui/common/app_colors.dart';
import 'package:dinesync/ui/common/uihelper/snakbar_helper.dart';
import 'package:dinesync/ui/widgets/common/top/top.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../common/uihelper/text_veiw_helper.dart';
import 'resturantcomplete_viewmodel.dart';

class ResturantcompleteView extends StackedView<ResturantcompleteViewModel> {
  const ResturantcompleteView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    ResturantcompleteViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: FutureBuilder(
            future:
                ApiHelper.getrest(viewModel.sharedpref.readString('number')),
            builder: (BuildContext context,
                AsyncSnapshot<Map<dynamic, dynamic>> snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!['rest'] != {}) {
                  viewModel.loaddata(snapshot.data!['rest']);
                }
                return SingleChildScrollView(
                  child: Column(
                    children: [
                      Top(txt: "Resturant Details", iconData: Icons.restaurant),
                      text_view_helper(
                        hint: "Enter Resturant name",
                        controller: viewModel.name,
                        showicon: true,
                        icon: const Icon(Icons.table_bar_outlined),
                      )
                          .animate(delay: 500.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                      text_view_helper(
                        hint: "Enter Resturant Description",
                        controller: viewModel.description,
                        showicon: true,
                        maxline: null,
                        icon: const Icon(Icons.table_bar_outlined),
                      )
                          .animate(delay: 700.milliseconds)
                          .fade()
                          .moveY(begin: 50, end: 0),
                      Container(
                        width: screenWidth(context),
                        height: screenHeightCustom(context, 0.51),
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: getColorWithOpacity(kcLightGrey, 0.1)),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  text_helper(
                                    data: "Monday",
                                    font: poppins,
                                    color: kcPrimaryColor,
                                    size: fontSize14,
                                    bold: true,
                                  ),
                                  text_helper(
                                    data: "Tuesday",
                                    font: poppins,
                                    color: kcPrimaryColor,
                                    size: fontSize14,
                                    bold: true,
                                  ),
                                  text_helper(
                                    data: "Wednesday",
                                    font: poppins,
                                    color: kcPrimaryColor,
                                    size: fontSize14,
                                    bold: true,
                                  ),
                                  text_helper(
                                    data: "Thursday",
                                    font: poppins,
                                    color: kcPrimaryColor,
                                    size: fontSize14,
                                    bold: true,
                                  ),
                                  text_helper(
                                    data: "Friday",
                                    font: poppins,
                                    color: kcPrimaryColor,
                                    size: fontSize14,
                                    bold: true,
                                  ),
                                  text_helper(
                                    data: "Sat",
                                    font: poppins,
                                    color: kcPrimaryColor,
                                    size: fontSize14,
                                    bold: true,
                                  ),
                                  text_helper(
                                    data: "Sunday",
                                    font: poppins,
                                    color: kcPrimaryColor,
                                    size: fontSize14,
                                    bold: true,
                                  ),
                                ],
                              ),
                            ),
                            horizontalSpaceSmall,
                            Expanded(
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  textviewhelper(viewModel.mons, context),
                                  textviewhelper(viewModel.tues, context),
                                  textviewhelper(viewModel.weds, context),
                                  textviewhelper(viewModel.thus, context),
                                  textviewhelper(viewModel.firs, context),
                                  textviewhelper(viewModel.sats, context),
                                  textviewhelper(viewModel.suns, context),
                                ],
                              ),
                            ),
                            horizontalSpaceSmall,
                            Expanded(
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  textviewhelper(viewModel.mone, context),
                                  textviewhelper(viewModel.tuee, context),
                                  textviewhelper(viewModel.wede, context),
                                  textviewhelper(viewModel.thue, context),
                                  textviewhelper(viewModel.fire, context),
                                  textviewhelper(viewModel.sate, context),
                                  textviewhelper(viewModel.sune, context),
                                ],
                              ),
                            ),
                          ],
                        ),
                      )
                          .animate(delay: 900.milliseconds)
                          .fade()
                          .moveY(begin: 80, end: 0),
                      viewModel.fImages.isEmpty
                          ? const SizedBox.shrink()
                          : SizedBox(
                              width: screenWidth(context),
                              height: screenHeightCustom(context, 0.2),
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                children: viewModel.fImages
                                    .map((e) => Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(30),
                                            child: CachedNetworkImage(
                                              imageUrl: e,
                                              imageBuilder:
                                                  (context, imageProvider) =>
                                                      Container(
                                                width: screenWidthCustom(
                                                    context, 0.25),
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    image: imageProvider,
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                              placeholder: (context, url) =>
                                                  displaysimpleprogress(
                                                      context),
                                              errorWidget:
                                                  (context, url, error) =>
                                                      const Icon(
                                                Icons.error,
                                                color: white,
                                              ),
                                            ),
                                          ),
                                        ))
                                    .toList(),
                              ),
                            )
                              .animate(delay: 900.milliseconds)
                              .fade()
                              .moveY(begin: 80, end: 0),
                      viewModel.selectedImages.isEmpty
                          ? const SizedBox.shrink()
                          : SizedBox(
                              width: screenWidth(context),
                              height: screenHeightCustom(context, 0.2),
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                children: viewModel.selectedImages
                                    .map((e) => Padding(
                                          padding: const EdgeInsets.all(10),
                                          child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              child: Image.file(File(e.path))),
                                        ))
                                    .toList(),
                              ),
                            ).animate(delay: 200.milliseconds).fade(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          button_helper(
                                  onpress: () => viewModel.pickImages(),
                                  color: kcPrimaryColorlight,
                                  width: screenWidthCustom(context, 0.4),
                                  child: text_helper(
                                      data: "Add Pics",
                                      font: roboto,
                                      color: white,
                                      bold: true,
                                      size: fontSize14))
                              .animate(delay: 900.milliseconds)
                              .fade()
                              .moveY(begin: 50, end: 0),
                          button_helper(
                                  onpress: () => viewModel.save(context),
                                  color: kcPrimaryColorlight,
                                  width: screenWidthCustom(context, 0.4),
                                  child: text_helper(
                                      data: "Save",
                                      font: roboto,
                                      color: white,
                                      bold: true,
                                      size: fontSize14))
                              .animate(delay: 1100.milliseconds)
                              .fade()
                              .moveY(begin: 50, end: 0),
                        ],
                      ),
                    ],
                  ),
                );
              } else if (snapshot.hasError) {
                return const Icon(
                  Icons.error,
                  color: kcPrimaryColor,
                );
              } else {
                return displaysimpleprogress(context);
              }
            },
          ),
        ));
  }

  Widget textviewhelper(
      TextEditingController controller, BuildContext context) {
    return SizedBox(
      width: screenWidthCustom(context, 0.2),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
            border: InputBorder.none,
            hintText: "9:00 am",
            hintStyle: text_helper.customstyle(
                poppins, kcLightGrey, fontSize12, context, false)),
        style: text_helper.customstyle(
            poppins, kcDarkGreyColor, fontSize12, context, false),
      ),
    );
  }

  @override
  ResturantcompleteViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      ResturantcompleteViewModel();
}
