// ignore_for_file: use_build_context_synchronously

import 'dart:io';

import 'package:dinesync/ui/common/apihelpers/apihelper.dart';
import 'package:dinesync/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:flutter/cupertino.dart';
import 'package:image_picker/image_picker.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/uihelper/snakbar_helper.dart';

class ResturantcompleteViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final sharedpref = locator<SharedprefService>();

  TextEditingController name = TextEditingController();
  TextEditingController description = TextEditingController();

  TextEditingController mons = TextEditingController();
  TextEditingController tues = TextEditingController();
  TextEditingController weds = TextEditingController();
  TextEditingController thus = TextEditingController();
  TextEditingController firs = TextEditingController();
  TextEditingController sats = TextEditingController();
  TextEditingController suns = TextEditingController();

  TextEditingController mone = TextEditingController();
  TextEditingController tuee = TextEditingController();
  TextEditingController wede = TextEditingController();
  TextEditingController thue = TextEditingController();
  TextEditingController fire = TextEditingController();
  TextEditingController sate = TextEditingController();
  TextEditingController sune = TextEditingController();

  Future<void> save(BuildContext context) async {
    displayprogress(context);
    var i = await ApiHelper.getrest(sharedpref.readString('number'));
    if (i['status']) {
      List<String> finalimages = [];
      for (var i in fImages) {
        finalimages.add(i);
      }
      for (var element in selectedImages) {
        finalimages.add(await FirebaseHelper.uploadFile(
            File(element.path), sharedpref.readString("number")));
      }
      bool check = await ApiHelper.updateregistration(
          sharedpref.readString('number'),
          name.text,
          description.text,
          mons.text,
          mone.text,
          tues.text,
          tuee.text,
          weds.text,
          wede.text,
          thus.text,
          thue.text,
          firs.text,
          fire.text,
          sats.text,
          sate.text,
          suns.text,
          sune.text,
          finalimages,
          context);
      if (check) {
        hideprogress(context);
        _navigationService.back();
      } else {
        hideprogress(context);
      }
    } else {
      List<String> finalimages = [];
      for (var element in selectedImages) {
        finalimages.add(await FirebaseHelper.uploadFile(
            File(element.path), sharedpref.readString("number")));
      }
      bool check = await ApiHelper.restregistration(
          sharedpref.readString('number'),
          name.text,
          description.text,
          mons.text,
          mone.text,
          tues.text,
          tuee.text,
          weds.text,
          wede.text,
          thus.text,
          thue.text,
          firs.text,
          fire.text,
          sats.text,
          sate.text,
          suns.text,
          sune.text,
          finalimages,
          context);
      if (check) {
        hideprogress(context);
        _navigationService.back();
      } else {
        hideprogress(context);
        show_snackbar(context, 'try again later');
      }
    }
  }

  List fImages = [];
  void loaddata(Map data) {
    fImages = data['image'];
    name.text = data['name'] ?? "";
    description.text = data['des'] ?? "";
    mons.text = data['mons'] ?? "";
    mone.text = data['mone'] ?? "";
    tues.text = data['tues'] ?? "";
    tuee.text = data['tuee'] ?? "";
    weds.text = data['weds'] ?? "";
    wede.text = data['wede'] ?? "";
    thus.text = data['thus'] ?? "";
    thue.text = data['thue'] ?? "";
    firs.text = data['firs'] ?? "";
    fire.text = data['fire'] ?? "";
    sats.text = data['sats'] ?? "";
    sate.text = data['sate'] ?? "";
    suns.text = data['suns'] ?? "";
    sune.text = data['sune'] ?? "";
  }

  List<XFile> selectedImages = [];
  Future<void> pickImages() async {
    final picker = ImagePicker();
    final pickedImages = await picker.pickMultiImage(
      imageQuality: 10,
    );
    selectedImages = pickedImages;
    notifyListeners();
  }
}
