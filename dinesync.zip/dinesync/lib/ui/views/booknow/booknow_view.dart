// ignore_for_file: must_be_immutable

import 'package:dinesync/ui/common/app_colors.dart';
import 'package:dinesync/ui/common/ui_helpers.dart';
import 'package:dinesync/ui/common/uihelper/button_helper.dart';
import 'package:dinesync/ui/widgets/common/top/top.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/uihelper/text_helper.dart';
import 'booknow_viewmodel.dart';

class BooknowView extends StackedView<BooknowViewModel> {
  BooknowView(
      {Key? key,
      required this.table,
      required this.menu,
      required this.people,
      required this.date,
      required this.timee,
      required this.times})
      : super(key: key);
  String table, date, times, timee;
  List menu;
  String people;

  @override
  Widget builder(
    BuildContext context,
    BooknowViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: Column(
          children: [
            Top(txt: "Cart", iconData: Icons.shopping_cart),
            SizedBox(
              width: screenWidth(context),
              height: 80,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  top(context, 'assets/table.png', table),
                  top(context, 'assets/user.png', people),
                  top(context, 'assets/date.png', date),
                  top(context, 'assets/time.png', times),
                  top(context, 'assets/time.png', timee),
                ],
              ),
            ),
            Container(
              width: screenWidth(context),
              height: 50,
              margin: const EdgeInsets.all(10),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: getColorWithOpacity(skin, 0.2)),
              child: text_helper(
                data: "Confirm order",
                font: poppins,
                textAlign: TextAlign.start,
                color: kcPrimaryColor,
                size: fontSize12,
                bold: true,
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: viewModel.menus.length,
                itemBuilder: (BuildContext context, int index) {
                  return Container(
                    padding: const EdgeInsets.all(10),
                    margin: const EdgeInsets.all(10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              text_helper(
                                data: viewModel.menus[index]['itemname'],
                                font: poppins,
                                bold: true,
                                color: kcDarkGreyColor,
                                size: fontSize12,
                                textAlign: TextAlign.start,
                              ),
                              text_helper(
                                data: viewModel.menus[index]['itemprice'],
                                font: poppins,
                                bold: true,
                                color: kcPrimaryColorlight,
                                size: fontSize10,
                                textAlign: TextAlign.start,
                              ),
                              text_helper(
                                data: viewModel.menus[index]['itemdes'],
                                font: poppins,
                                bold: true,
                                color: kcLightGrey,
                                size: fontSize10,
                                textAlign: TextAlign.start,
                              ),
                            ],
                          ),
                        ),
                        Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                button_helper(
                                    onpress: () => viewModel.plus(index),
                                    color: kcPrimaryColor,
                                    width: screenWidthCustom(context, 0.1),
                                    child: const Icon(
                                      Icons.add,
                                      color: white,
                                    )),
                                text_helper(
                                  data: viewModel.menus[index]['quantity'],
                                  font: poppins,
                                  color: kcDarkGreyColor,
                                  size: fontSize14,
                                  bold: true,
                                ),
                                button_helper(
                                    onpress: () => viewModel.minus(index),
                                    color: kcPrimaryColor,
                                    width: screenWidthCustom(context, 0.1),
                                    child: const Icon(
                                      Icons.minimize,
                                      color: white,
                                    ))
                              ],
                            ),
                            text_helper(
                              data: "Rs " + viewModel.menus[index]['editprice'],
                              font: poppins,
                              color: kcPrimaryColorlight,
                              size: fontSize12,
                              bold: true,
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: InkWell(
        onTap: () =>
            viewModel.book(context, '0000-0000000', date, times, timee),
        child: Container(
          width: screenWidth(context),
          height: 50,
          margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(
              color: kcPrimaryColorlight,
              borderRadius: BorderRadius.circular(10)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              text_helper(
                  data: "Confirm Booking",
                  font: poppins,
                  color: white,
                  bold: true,
                  size: fontSize14),
              horizontalSpaceSmall,
              Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20), color: white),
                child: const Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: kcPrimaryColor,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget top(BuildContext context, String img, String txt) {
    return Container(
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: getColorWithOpacity(kcLightGrey, 0.2)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            img,
            width: screenWidthCustom(context, 0.2),
            height: screenWidthCustom(context, 0.1),
          ),
          horizontalSpaceTiny,
          text_helper(
              data: txt,
              font: poppins,
              bold: true,
              color: kcDarkGreyColor,
              size: fontSize16)
        ],
      ),
    );
  }

  @override
  void onViewModelReady(BooknowViewModel viewModel) =>
      viewModel.first(menu, table, people);

  @override
  BooknowViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      BooknowViewModel();
}
