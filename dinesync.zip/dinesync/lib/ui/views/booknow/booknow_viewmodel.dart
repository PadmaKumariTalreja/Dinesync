// ignore_for_file: use_build_context_synchronously

import 'package:dinesync/ui/common/apihelpers/apihelper.dart';
import 'package:dinesync/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:dinesync/ui/common/uihelper/snakbar_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../services/sharedpref_service.dart';

class BooknowViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();

  String table = '';
  String people = '';
  List menus = [];
  void first(List men, String tab, String peoples) {
    people = peoples;
    table = tab;
    for (int i = 0; i < men.length; i++) {
      Map fdata = {};
      fdata['_id'] = men[i]['_id'];
      fdata['itemname'] = men[i]['itemname'];
      fdata['itemprice'] = men[i]['itemprice'];
      fdata['editprice'] = men[i]['itemprice'];
      fdata['itemdes'] = men[i]['itemdes'];
      fdata['quantity'] = '1';
      menus.add(fdata);
    }
  }

  void plus(int index) {
    Map data = menus[index];
    data['editprice'] =
        '${int.parse(data['editprice']) + int.parse(data['itemprice'])}';
    data['quantity'] = '${int.parse(data['quantity']) + 1}';
    notifyListeners();
  }

  void minus(int index) {
    Map data = menus[index];
    if (int.parse(data['quantity']) > 0) {
      data['editprice'] =
          '${int.parse(data['editprice']) - int.parse(data['itemprice'])}';
      data['quantity'] = '${int.parse(data['quantity']) - 1}';
      notifyListeners();
    }
  }

  Future<void> book(BuildContext context, String number, String date,
      String times, String timee) async {
    displayprogress(context);
    Map wdata = await ApiHelper.getwallet(_sharedpref.readString('number'));
    if (wdata['status']) {
      Map rdata = await ApiHelper.getwallet(number);
      int price = 0;
      for (var element in menus) {
        price += int.parse(element['editprice']);
      }
      bool ru = await ApiHelper.updatewallet(
          number,
          rdata['rest']['notpay'],
          rdata['rest']['paid'],
          "${int.parse(rdata['rest']['topup']) + price}",
          price.toString(),
          context);
      if (ru) {
        wdata = await ApiHelper.getwallet(_sharedpref.readString('number'));
        bool uw = await ApiHelper.updatewallet(
            _sharedpref.readString('number'),
            wdata['rest']['notpay'],
            "${int.parse(wdata['rest']['paid']) + price}",
            wdata['rest']['topup'],
            price.toString(),
            context);
        if (uw) {
          bool result = await ApiHelper.ordergistration(
              number,
              _sharedpref.readString('number'),
              people,
              table,
              menus,
              times,
              timee,
              date,
              "new",
              context);
          if (result) {
            FirebaseHelper.sendnotificationtoadmin("New Order",
                "New order from ${_sharedpref.readString('name')}");
            hideprogress(context);
            _navigationService.back();
            _navigationService.back();
            _navigationService.back();
          }
        }
      }
    }
  }
}
