// ignore_for_file: must_be_immutable

import 'package:animated_rating_stars/animated_rating_stars.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dinesync/ui/common/apihelpers/apihelper.dart';
import 'package:dinesync/ui/common/app_colors.dart';
import 'package:dinesync/ui/common/app_strings.dart';
import 'package:dinesync/ui/common/ui_helpers.dart';
import 'package:dinesync/ui/common/uihelper/button_helper.dart';
import 'package:dinesync/ui/common/uihelper/snakbar_helper.dart';
import 'package:dinesync/ui/common/uihelper/text_helper.dart';
import 'package:dinesync/ui/widgets/common/customslider/customslider.dart';
import 'package:dinesync/ui/widgets/common/top/top.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import 'userresturantview_viewmodel.dart';

class UserresturantviewView extends StackedView<UserresturantviewViewModel> {
  UserresturantviewView(
      {Key? key,
      required this.table,
      required this.people,
      required this.date,
      required this.timee,
      required this.times})
      : super(key: key);
  String table, date, times, timee;
  String people;

  @override
  Widget builder(
    BuildContext context,
    UserresturantviewViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: Column(
          children: [
            Top(txt: "Menu", iconData: Icons.menu),
            SizedBox(
              width: screenWidth(context),
              height: 80,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  top(context, 'assets/table.png', table),
                  top(context, 'assets/user.png', people),
                  top(context, 'assets/date.png', date),
                  top(context, 'assets/time.png', times),
                  top(context, 'assets/time.png', timee),
                ],
              ),
            ),
            SizedBox(
              width: screenWidth(context),
              height: 30,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: mcat
                    .map((e) => InkWell(
                          onTap: () {
                            viewModel.s = e;
                            viewModel.notifyListeners();
                          },
                          child: Container(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Column(
                              children: [
                                text_helper(
                                  data: e,
                                  font: poppins,
                                  color: viewModel.s == e
                                      ? kcPrimaryColorlight
                                      : kcDarkGreyColor,
                                  size: fontSize12,
                                  bold: true,
                                ),
                                verticalSpaceTiny,
                                Container(
                                  width: 50,
                                  height: 2,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: viewModel.s == e
                                          ? kcPrimaryColorlight
                                          : kcDarkGreyColor),
                                )
                              ],
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ),
            Expanded(
              child: FutureBuilder(
                future: ApiHelper.getallmenu('0000-0000000', viewModel.s),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                      itemCount: snapshot.data['rest'].length,
                      itemBuilder: (BuildContext context, int index) {
                        return InkWell(
                          onTap: () =>
                              viewModel.addcart(snapshot.data['rest'][index]),
                          child: Container(
                            width: screenWidth(context),
                            height: 150,
                            padding: const EdgeInsets.all(10),
                            margin: const EdgeInsets.all(10),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            text_helper(
                                                data: snapshot.data['rest']
                                                    [index]['cat'],
                                                font: poppins,
                                                color: kcPrimaryColorlight,
                                                size: fontSize12),
                                            text_helper(
                                                data: snapshot.data['rest']
                                                    [index]['itemname'],
                                                bold: true,
                                                font: poppins,
                                                color: kcDarkGreyColor,
                                                size: fontSize14),
                                            text_helper(
                                              data: snapshot.data['rest'][index]
                                                  ['itemdes'],
                                              textAlign: TextAlign.start,
                                              font: poppins,
                                              color: kcDarkGreyColor,
                                              size: fontSize10,
                                            ),
                                          ],
                                        ),
                                      ),
                                      text_helper(
                                          data: 'starting from ' +
                                              snapshot.data['rest'][index]
                                                  ['itemprice'],
                                          font: poppins,
                                          color: kcDarkGreyColor,
                                          size: fontSize12),
                                      AnimatedRatingStars(
                                        initialRating: int.parse(
                                                snapshot.data['rest'][index]
                                                    ['itemrating']) /
                                            int.parse(snapshot.data['rest']
                                                [index]['itemuser']),
                                        minRating: 0.0,
                                        maxRating: 5.0,
                                        filledColor: Colors.amber,
                                        emptyColor: Colors.grey,
                                        filledIcon: Icons.star,
                                        halfFilledIcon: Icons.star_half,
                                        emptyIcon: Icons.star_border,
                                        onChanged: (double rating) {},
                                        displayRatingValue: true,
                                        interactiveTooltips: true,
                                        customFilledIcon: Icons.star,
                                        customHalfFilledIcon: Icons.star_half,
                                        customEmptyIcon: Icons.star_border,
                                        starSize: 20,
                                        animationDuration:
                                            const Duration(milliseconds: 300),
                                        animationCurve: Curves.easeInOut,
                                        readOnly: true,
                                      ),
                                    ],
                                  ),
                                ),
                                Column(
                                  children: [
                                    SizedBox(
                                        width: screenWidthCustom(context, 0.4),
                                        child: Customslider(
                                            data: snapshot.data['rest'][index]
                                                ['image'])),
                                    verticalSpaceTiny,
                                    viewModel.checking(
                                            snapshot.data['rest'][index]
                                                ['itemname'],
                                            snapshot.data['rest'][index]
                                                ['mcat'])
                                        ? Container(
                                            padding: const EdgeInsets.fromLTRB(
                                                5, 0, 5, 0),
                                            width:
                                                screenWidthCustom(context, 0.2),
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(50),
                                                color: kcPrimaryColorlight),
                                            child: const Icon(
                                              Icons.check,
                                              color: white,
                                            ),
                                          )
                                        : const SizedBox.shrink()
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  } else if (snapshot.hasError) {
                    return const Icon(
                      Icons.error,
                      color: kcDarkGreyColor,
                    );
                  } else {
                    return displaysimpleprogress(context);
                  }
                },
              ),
            )
          ],
        ),
      ),
      bottomNavigationBar: viewModel.cart.isEmpty
          ? const SizedBox.shrink()
          : InkWell(
              onTap: () =>
                  viewModel.order(context, table, people, date, times, timee),
              child: Container(
                width: screenWidth(context),
                height: 50,
                margin: const EdgeInsets.all(10),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: kcPrimaryColorlight,
                    borderRadius: BorderRadius.circular(10)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          border: Border.all(width: 1, color: white)),
                      child: Center(
                        child: text_helper(
                            data: viewModel.cart.length.toString(),
                            font: poppins,
                            color: white,
                            size: fontSize12),
                      ),
                    ),
                    text_helper(
                        data: "View your Cart",
                        font: poppins,
                        color: white,
                        bold: true,
                        size: fontSize14),
                    text_helper(
                        data: "Rs ${viewModel.price}",
                        font: poppins,
                        color: white,
                        bold: true,
                        size: fontSize14),
                  ],
                ),
              ),
            ),
    );
  }

  Widget top(BuildContext context, String img, String txt) {
    return Container(
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: getColorWithOpacity(kcLightGrey, 0.2)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            img,
            width: screenWidthCustom(context, 0.2),
            height: screenWidthCustom(context, 0.1),
          ),
          horizontalSpaceTiny,
          text_helper(
              data: txt,
              font: poppins,
              bold: true,
              color: kcDarkGreyColor,
              size: fontSize16)
        ],
      ),
    );
  }

  @override
  UserresturantviewViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      UserresturantviewViewModel();
}
