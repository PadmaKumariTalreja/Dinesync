import 'package:dinesync/ui/common/uihelper/snakbar_helper.dart';
import 'package:dinesync/ui/views/booknow/booknow_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';

class UserresturantviewViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();

  String s = 'Appetizers';

  List cart = [];
  int price = 0;
  void addcart(Map e) {
    if (cart.isEmpty) {
      cart.add(e);
      priceadd();
      notifyListeners();
    } else {
      if (!checking(e['itemname'], e['mcat'])) {
        cart.add(e);
        priceadd();
        notifyListeners();
      }
    }
  }

  void priceadd() {
    price = 0;
    for (var element in cart) {
      price += int.parse(element['itemprice']);
    }
  }

  bool checking(String name, String mcat) {
    for (var element in cart) {
      if (name == element['itemname'] && mcat == element['mcat']) {
        return true;
      }
    }
    return false;
  }

  void order(BuildContext context, String table, String people, String date,
      String times, String timee) {
    if (cart.isEmpty) {
      show_snackbar(context, "Select a table to continue");
    } else {
      _navigationService.navigateWithTransition(
          BooknowView(
            table: table,
            menu: cart,
            people: people,
            date: date,
            timee: timee,
            times: times,
          ),
          routeName: Routes.booknowView,
          transitionStyle: Transition.rightToLeft);
    }
  }
}
