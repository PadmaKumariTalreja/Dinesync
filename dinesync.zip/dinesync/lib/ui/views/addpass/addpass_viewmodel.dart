// ignore_for_file: use_build_context_synchronously

import 'package:dinesync/ui/views/home/home_view.dart';
import 'package:dinesync/ui/views/resturantowner/resturantowner_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/fire_service.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/apihelpers/apihelper.dart';
import '../../common/apihelpers/firebsaeuploadhelper.dart';
import '../../common/uihelper/snakbar_helper.dart';

class AddpassViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();
  final _fireService = locator<FireService>();

  TextEditingController pass = TextEditingController();
  TextEditingController conpass = TextEditingController();

  void next(BuildContext context) {
    if (pass.text.isEmpty || conpass.text.isEmpty) {
      show_snackbar(context, "all fields");
    } else if (pass.text != conpass.text) {
      show_snackbar(context, "pass and confirm pass do not match");
    } else {
      displayprogress(context);
      Future<bool> result = _fireService.messaging.getToken().then((value) {
        _sharedpref.setString('deviceid', value.toString());
        return ApiHelper.registration(
          _sharedpref.readString('name'),
          _sharedpref.readString('cnic'),
          _sharedpref.readString('number'),
          _sharedpref.readString('address'),
          _sharedpref.readString('dob'),
          _sharedpref.readString('img'),
          pass.text,
          value.toString(),
          context,
        );
      });
      result.then((value) async {
        bool check = await ApiHelper.registerwallet(
            _sharedpref.readString('number'), context);
        if (check) {
          if (value) {
            await FirebaseHelper.sendnotificationto(
                _sharedpref.readString('deviceid'),
                "Signup Sucessfully",
                "Welcome ${_sharedpref.readString('name')}");
            hideprogress(context);
            _sharedpref.setString('auth', 't');
            _navigationService.clearStackAndShow(Routes.homeView);
            _navigationService.replaceWithTransition(const HomeView(),
                routeName: Routes.homeView,
                transitionStyle: Transition.rightToLeft);
          } else {
            hideprogress(context);
            show_snackbar(context, 'try again later');
          }
        } else {
          show_snackbar(context, "Try again later");
        }
      });
    }
  }
}
