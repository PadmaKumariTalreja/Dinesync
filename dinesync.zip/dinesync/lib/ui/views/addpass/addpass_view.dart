import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../common/uihelper/text_veiw_helper.dart';
import 'addpass_viewmodel.dart';

class AddpassView extends StackedView<AddpassViewModel> {
  const AddpassView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    AddpassViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  text_helper(
                    data: "Add your password",
                    font: poppins,
                    color: kcPrimaryColor,
                    size: fontSize22,
                    bold: true,
                  ),
                  SizedBox(
                      width: screenWidthCustom(context, 0.2),
                      height: screenWidthCustom(context, 0.2),
                      child: Lottie.asset('assets/loading.json')),
                ],
              )
                  .animate(delay: 500.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
              text_view_helper(
                hint: "Enter Password",
                controller: viewModel.pass,
                showicon: true,
                obsecure: true,
                icon: const Icon(Icons.password),
              )
                  .animate(delay: 700.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
              text_view_helper(
                hint: "Confirm Password",
                controller: viewModel.conpass,
                showicon: true,
                obsecure: true,
                icon: const Icon(Icons.password),
              )
                  .animate(delay: 900.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
              button_helper(
                      onpress: () => viewModel.next(context),
                      color: kcPrimaryColorlight,
                      width: screenWidthCustom(context, 0.6),
                      padding: const EdgeInsetsDirectional.all(8),
                      child: text_helper(
                        data: "Make Account",
                        font: poppins,
                        color: white,
                        size: fontSize18,
                        bold: true,
                      ))
                  .animate(delay: 1100.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
            ],
          ),
        ));
  }

  @override
  AddpassViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      AddpassViewModel();
}
