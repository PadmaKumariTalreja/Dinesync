import 'package:dinesync/ui/common/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/button_helper.dart';
import '../../common/uihelper/text_helper.dart';
import 'signup_viewmodel.dart';

class SignupView extends StackedView<SignupViewModel> {
  const SignupView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    SignupViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: Column(
          children: [
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    text_helper(
                      data: "Welcome",
                      font: poppins,
                      color: kcPrimaryColor,
                      size: fontSize22,
                      bold: true,
                    ),
                    SizedBox(
                        width: screenWidthCustom(context, 0.2),
                        height: screenWidthCustom(context, 0.2),
                        child: Lottie.asset('assets/loading.json')),
                    text_helper(
                      data: "DineSync",
                      font: poppins,
                      color: kcPrimaryColorlight,
                      size: fontSize22,
                      bold: true,
                    ),
                  ],
                ).animate(delay: 500.milliseconds).fade(),
                text_helper(
                        data: "Please Select a category to Continue",
                        font: poppins,
                        color: kcDarkGreyColor,
                        size: fontSize14)
                    .animate(delay: 700.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0)
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                button_helper(
                        onpress: () => viewModel.rest(),
                        color: white,
                        width: screenWidthCustom(context, 0.4),
                        padding: const EdgeInsetsDirectional.all(10),
                        border: Border.all(width: 1, color: kcPrimaryColor),
                        boxshadow: [
                          BoxShadow(
                              offset: const Offset(0, 0),
                              spreadRadius: 1,
                              blurRadius: 1,
                              color: viewModel.cat == 'rest'
                                  ? kcPrimaryColor
                                  : white)
                        ],
                        child: Column(
                          children: [
                            Image.asset(
                              'assets/restowner.png',
                              height: screenWidthCustom(context, 0.5),
                              width: screenWidthCustom(context, 0.5),
                            ).animate(delay: 900.milliseconds).fade(),
                            verticalSpaceSmall,
                            text_helper(
                              data: "Resturant Owner",
                              font: montserrat,
                              color: kcPrimaryColorlight,
                              size: fontSize14,
                              bold: true,
                            ).animate(delay: 900.milliseconds).fade()
                          ],
                        ))
                    .animate(delay: 900.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
                button_helper(
                        onpress: () => viewModel.simple(),
                        color: white,
                        width: screenWidthCustom(context, 0.4),
                        padding: const EdgeInsetsDirectional.all(10),
                        border: Border.all(width: 1, color: kcPrimaryColor),
                        boxshadow: [
                          BoxShadow(
                              offset: const Offset(0, 0),
                              spreadRadius: 1,
                              blurRadius: 1,
                              color: viewModel.cat == 'user'
                                  ? kcPrimaryColor
                                  : white)
                        ],
                        child: Column(
                          children: [
                            Image.asset(
                              'assets/user.png',
                              height: screenWidthCustom(context, 0.5),
                              width: screenWidthCustom(context, 0.5),
                            ).animate(delay: 1100.milliseconds).fade(),
                            verticalSpaceSmall,
                            text_helper(
                              data: "Hungry\nPerson",
                              font: montserrat,
                              color: kcPrimaryColorlight,
                              size: fontSize14,
                              bold: true,
                            ).animate(delay: 1100.milliseconds).fade()
                          ],
                        ))
                    .animate(delay: 1100.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
              ],
            ),
            button_helper(
                    onpress: () => viewModel.next(context),
                    color: kcPrimaryColorlight,
                    width: screenHeightCustom(context, 0.2),
                    child: text_helper(
                      data: "Next",
                      font: poppins,
                      color: white,
                      size: fontSize18,
                      bold: true,
                    ))
                .animate(delay: 1300.milliseconds)
                .fade()
                .moveY(begin: 50, end: 0),
            InkWell(
              onTap: () => viewModel.login(),
              child: text_helper(
                data: "Already Have Account",
                font: poppins,
                color: kcPrimaryColor,
                size: fontSize12,
              ),
            ).animate(delay: 1500.milliseconds).fade().moveY(begin: 50, end: 0),
          ],
        ),
      ),
    );
  }

  @override
  SignupViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      SignupViewModel();
}
