import 'package:dinesync/ui/common/uihelper/snakbar_helper.dart';
import 'package:dinesync/ui/views/details/details_view.dart';
import 'package:dinesync/ui/views/login/login_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';

class SignupViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final _sharedpref = locator<SharedprefService>();

  String cat = '';

  void rest() {
    cat = 'rest';
    notifyListeners();
  }

  void simple() {
    cat = 'user';
    notifyListeners();
  }

  void next(BuildContext context) {
    if (cat == '') {
      show_snackbar(context, "Please Select a Category");
    } else {
      _sharedpref.setString("cat", cat);
      _navigationService.replaceWithTransition(const DetailsView(),
          routeName: Routes.detailsView,
          transitionStyle: Transition.rightToLeft);
    }
  }

  void login() {
    _navigationService.replaceWithTransition(const LoginView(),
        routeName: Routes.loginView, transitionStyle: Transition.rightToLeft);
  }
}
