import 'package:dinesync/ui/common/apihelpers/apihelper.dart';
import 'package:dinesync/ui/common/app_colors.dart';
import 'package:dinesync/ui/common/app_strings.dart';
import 'package:dinesync/ui/common/ui_helpers.dart';
import 'package:dinesync/ui/common/uihelper/snakbar_helper.dart';
import 'package:dinesync/ui/common/uihelper/text_helper.dart';
import 'package:dinesync/ui/widgets/common/top/top.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import 'userorders_viewmodel.dart';

class UserordersView extends StackedView<UserordersViewModel> {
  const UserordersView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    UserordersViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top(txt: "Orders", iconData: Icons.bookmark_border),
              Row(children: [
                btn("all", viewModel),
                btn("new", viewModel),
                btn("cancle", viewModel),
                btn("old", viewModel),
              ]),
              Expanded(
                child: FutureBuilder(
                  future: ApiHelper.getbyuser(
                      viewModel.sharedpref.readString('number')),
                  builder: (BuildContext context,
                      AsyncSnapshot<Map<dynamic, dynamic>> snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data!['rest'].length,
                        itemBuilder: (BuildContext context, int index) {
                          if (viewModel.val == 'all') {
                            return listdatamain(
                                context, snapshot, index, viewModel);
                          } else {
                            if (viewModel.val ==
                                snapshot.data!['rest'][index]['status']) {
                              return listdatamain(
                                  context, snapshot, index, viewModel);
                            } else {
                              return const SizedBox.shrink();
                            }
                          }
                        },
                      );
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              )
            ],
          ),
        ));
  }

  Widget listdatamain(BuildContext context, AsyncSnapshot snapshot, int index,
      UserordersViewModel viewModel) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
                spreadRadius: 2,
                blurRadius: 2,
                offset: const Offset(2, 2),
                color: getColorWithOpacity(kcLightGrey, 0.2))
          ],
          color: white),
      child: Column(
        children: [
          snapshot.data!['rest'][index]['family'].toString() == 'take away'
              ? text_helper(
                  data: "Take Away",
                  font: poppins,
                  color: kcDarkGreyColor,
                  size: fontSize16)
              : data("Person :  ",
                  snapshot.data!['rest'][index]['family'].toString()),
          data(
              "Date :  ", snapshot.data!['rest'][index]['datetime'].toString()),
          snapshot.data!['rest'][index]['family'].toString() == 'take away'
              ? const SizedBox.shrink()
              : data("Table number :  ",
                  snapshot.data!['rest'][index]['table'].toString()),
          snapshot.data!['rest'][index]['family'].toString() == 'take away'
              ? data(
                  "Time :  ", snapshot.data!['rest'][index]['times'].toString())
              : data("Time Start :  ",
                  snapshot.data!['rest'][index]['times'].toString()),
          snapshot.data!['rest'][index]['family'].toString() == 'take away'
              ? const SizedBox.shrink()
              : data("Time End :  ",
                  snapshot.data!['rest'][index]['timee'].toString()),
          verticalSpaceTiny,
          Column(
            children: List.of(snapshot.data!['rest'][index]['menu'])
                .map((e) => listdata(e, viewModel, context))
                .toList(),
          )
        ],
      ),
    );
  }

  Widget data(String title, String des) {
    return Row(
      children: [
        text_helper(
          data: title,
          bold: true,
          font: poppins,
          color: kcPrimaryColor,
          size: fontSize12,
        ),
        text_helper(
          data: des,
          font: poppins,
          color: kcDarkGreyColor,
          size: fontSize12,
        ),
      ],
    );
  }

  Widget data2(String title, String des) {
    return Row(
      children: [
        text_helper(
          data: title,
          bold: true,
          font: poppins,
          color: white,
          size: fontSize12,
        ),
        text_helper(
          data: des,
          font: poppins,
          color: white,
          size: fontSize12,
        ),
      ],
    );
  }

  Widget listdata(Map e, UserordersViewModel viewModel, BuildContext context) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      child: Row(
        children: [
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                text_helper(
                    data: e['itemname'],
                    bold: true,
                    font: poppins,
                    color: kcDarkGreyColor,
                    size: fontSize14),
                text_helper(
                  data: e['itemdes'],
                  textAlign: TextAlign.start,
                  font: poppins,
                  color: kcDarkGreyColor,
                  size: fontSize10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    text_helper(
                        data: 'Total ' + e['editprice'],
                        font: poppins,
                        color: kcDarkGreyColor,
                        size: fontSize12),
                    text_helper(
                        data: 'Quantity ' + e['quantity'],
                        font: poppins,
                        color: kcDarkGreyColor,
                        size: fontSize12),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    ).animate().fade().moveX(begin: 50, end: 0);
  }

  Widget btn(String title, UserordersViewModel viewModel) {
    return InkWell(
      onTap: () {
        viewModel.val = title;
        viewModel.notifyListeners();
      },
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
        margin: const EdgeInsets.all(5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              width: 1,
              color: kcPrimaryColor,
            ),
            color: viewModel.val == title
                ? kcPrimaryColor
                : getColorWithOpacity(kcVeryLightGrey, 0.3)),
        child: text_helper(
            data: title,
            font: montserrat,
            color: viewModel.val != title ? kcPrimaryColor : white,
            size: fontSize14,
            bold: true),
      ),
    );
  }

  @override
  UserordersViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      UserordersViewModel();
}
