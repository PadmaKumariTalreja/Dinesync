import 'package:dinesync/ui/common/apihelpers/apihelper.dart';
import 'package:dinesync/ui/common/ui_helpers.dart';
import 'package:dinesync/ui/common/uihelper/button_helper.dart';
import 'package:dinesync/ui/common/uihelper/text_veiw_helper.dart';
import 'package:dinesync/ui/views/resturanttable/resturanttable_view.dart';
import 'package:dinesync/ui/views/reviews/reviews_view.dart';
import 'package:dinesync/ui/views/usercatview/usercatview_view.dart';
import 'package:dinesync/ui/views/userorders/userorders_view.dart';
import 'package:dinesync/ui/views/virtualgift/virtualgift_view.dart';
import 'package:dinesync/ui/views/wallet/wallet_view.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/app_colors.dart';
import '../../common/app_strings.dart';
import '../../common/uihelper/text_helper.dart';
import '../chat/chating/chating_view.dart';
import '../login/login_view.dart';
import '../userresturantview/userresturantview_view.dart';

class HomeViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final sharedpref = locator<SharedprefService>();

  TextEditingController search = TextEditingController();
  TextEditingController complaintc = TextEditingController();
  TextEditingController title = TextEditingController();

  void clear() {
    search.clear();
    notifyListeners();
  }

  void login() {
    sharedpref.remove('name');
    sharedpref.remove('cnic');
    sharedpref.remove('number');
    sharedpref.remove('address');
    sharedpref.remove('dob');
    sharedpref.remove('cat');
    sharedpref.remove('img');
    _navigationService.clearStackAndShow(Routes.loginView);
    _navigationService.replaceWithTransition(const LoginView(),
        routeName: Routes.loginView, transitionStyle: Transition.rightToLeft);
  }

  void next() {
    _navigationService.navigateWithTransition(
        ResturanttableView(
          user: true,
        ),
        routeName: Routes.resturanttableView,
        transitionStyle: Transition.rightToLeft);
  }

  void order(BuildContext context) {
    _navigationService.navigateWithTransition(
        UserresturantviewView(
            table: "take away",
            people: "take away",
            date: DateTime.now().toString().substring(0,10),
            timee: TimeOfDay.now().format(context),
            times: TimeOfDay.now().format(context)),
        routeName: Routes.resturanttableView,
        transitionStyle: Transition.rightToLeft);
  }

  void orders() {
    _navigationService.navigateWithTransition(const UserordersView(),
        routeName: Routes.userordersView,
        transitionStyle: Transition.rightToLeft);
  }

  void reviws(Map data) {
    _navigationService.navigateWithTransition(ReviewsView(data: data),
        routeName: Routes.reviewsView, transitionStyle: Transition.rightToLeft);
  }

  void wallet() {
    _navigationService.navigateWithTransition(const WalletView(),
        routeName: Routes.walletView, transitionStyle: Transition.rightToLeft);
  }

  void gift() {
    _navigationService.navigateWithTransition(const VirtualgiftView(),
        routeName: Routes.virtualgiftView,
        transitionStyle: Transition.rightToLeft);
  }

  void cat(String cat) {
    _navigationService.navigateWithTransition(
        UsercatviewView(
          cat: cat,
        ),
        routeName: Routes.usercatviewView,
        transitionStyle: Transition.rightToLeft);
  }

  Future<void> chat() async {
    Map c = await ApiHelper.registerchat(
        sharedpref.readString("number"), "0000-0000000");
    if (c['status']) {
      _navigationService.navigateWithTransition(
          ChatingView(
            id: c['message'],
            did: c['did'],
          ),
          routeName: Routes.chatingView,
          transitionStyle: Transition.rightToLeft);
    }
  }

  void complaint(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            backgroundColor: Colors.white,
            child: Container(
              width: screenWidth(context),
              padding: const EdgeInsets.all(10),
              color: Colors.white,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  text_helper(
                      data: 'Complaint',
                      font: poppins,
                      bold: true,
                      color: kcPrimaryColor,
                      size: fontSize14),
                  text_helper(
                      data: 'Enter your Complaint',
                      font: poppins,
                      color: kcPrimaryColor,
                      size: fontSize14),
                  verticalSpaceSmall,
                  text_view_helper(hint: "Complaint title", controller: title),
                  text_view_helper(
                      hint: "Complaint Description", controller: complaintc),
                  verticalSpaceSmall,
                  button_helper(
                      onpress: () async {
                        await ApiHelper.registercomplaint(
                            title.text, complaintc.text, context);
                        Navigator.pop(context);
                      },
                      color: kcPrimaryColor,
                      width: screenHeightCustom(context, 0.5),
                      child: text_helper(
                          data: "Submit",
                          font: poppins,
                          color: white,
                          size: fontSize14,
                          bold: true))
                ],
              ),
            ),
          );
        });
  }
}
