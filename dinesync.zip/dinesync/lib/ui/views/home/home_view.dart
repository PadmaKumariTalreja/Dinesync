import 'package:animated_rating_stars/animated_rating_stars.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'package:outline_search_bar/outline_search_bar.dart';
import 'package:stacked/stacked.dart';
import 'package:dinesync/ui/common/app_colors.dart';
import 'package:dinesync/ui/common/ui_helpers.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/app_strings.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_helper.dart';
import '../../widgets/common/customslider/customslider.dart';
import 'home_viewmodel.dart';

class HomeView extends StackedView<HomeViewModel> {
  const HomeView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    HomeViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: ListView(
          children: [
            OutlineSearchBar(
              margin: const EdgeInsets.fromLTRB(10, 8, 10, 0),
              backgroundColor: white,
              borderRadius: BorderRadius.circular(10),
              borderColor: kcLightGrey,
              borderWidth: 2,
              cursorColor: kcPrimaryColorlight,
              clearButtonColor: kcPrimaryColorlight,
              clearButtonIconColor: white,
              hintText: "Are you hungry !!",
              ignoreSpecialChar: true,
              searchButtonIconColor: kcPrimaryColorlight,
              hintStyle: text_helper.customstyle(
                  poppins, kcLightGrey, fontSize12, context, false),
              textStyle: text_helper.customstyle(
                  poppins, kcPrimaryColorlight, fontSize12, context, true),
              textEditingController: viewModel.search,
              onKeywordChanged: (String val) {
                viewModel.notifyListeners();
              },
            ),
            verticalSpaceSmall,
            div("Short Cuts", context),
            SizedBox(
              width: screenWidth(context),
              height: 100,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  transferscreen(
                      'assets/orders.png', context, 'order', viewModel.orders),
                  transferscreen(
                      'assets/wallet.png', context, 'wallet', viewModel.wallet),
                  transferscreen('assets/complaint.png', context, 'Complaint',
                      () => viewModel.complaint(context)),
                  transferscreen(
                      'assets/gift.png', context, 'Gifts', viewModel.gift),
                  transferscreen(
                      'assets/chats.png', context, 'Chat', viewModel.chat),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: ()=>viewModel.next(),
                  child: Container(
                    width: screenWidthCustom(context, 0.4),
                    margin: const EdgeInsets.all(10),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: getColorWithOpacity(red, 0.5),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.table_bar),
                        horizontalSpaceTiny,
                        text_helper(
                            data: "Book Tables",
                            font: poppins,
                            bold: true,
                            color: kcDarkGreyColor,
                            size: fontSize12),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: ()=>viewModel.order(context),
                  child: Container(
                    width: screenWidthCustom(context, 0.4),
                    margin: const EdgeInsets.all(10),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: getColorWithOpacity(red, 0.5),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.directions_walk),
                        horizontalSpaceTiny,
                        text_helper(
                            data: "Take Away",
                            font: poppins,
                            bold: true,
                            color: kcDarkGreyColor,
                            size: fontSize12),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            verticalSpaceSmall,
            div("categories", context),
            SizedBox(
              width: screenWidth(context),
              height: 150,
              child: ListView.builder(
                itemCount: cat.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (BuildContext context, int index) {
                  return InkWell(
                    onTap: () => viewModel.cat(cat[index]),
                    child: Container(
                      margin: const EdgeInsets.all(10),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: getColorWithOpacity(amber, 0.6),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(
                            'assets/dish.png',
                            width: screenWidthCustom(context, 0.1),
                            height: screenHeightCustom(context, 0.05),
                          ),
                          text_helper(
                              data: cat[index],
                              font: poppins,
                              bold: true,
                              color: kcDarkGreyColor,
                              size: fontSize10)
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            verticalSpaceSmall,
            div("People are looking for", context),
            FutureBuilder(
              future: ApiHelper.getallmenu('0000-0000000', ''),
              builder: (BuildContext context, AsyncSnapshot snapshot) {
                if (snapshot.hasData) {
                  return Column(
                    children: snapshot.data!['rest'].map<Widget>((e){
                      if (viewModel.search.text.isEmpty) {
                        return listdata(e, viewModel, context);
                      } else {
                        if (e['itemname']
                            .toString()
                            .toLowerCase()
                            .contains(viewModel.search.text.toLowerCase())) {
                          return listdata(e, viewModel, context);
                        } else {
                          return const SizedBox.shrink();
                        }
                      }
                    }).toList(),
                  );
                } else if (snapshot.hasError) {
                  return const Icon(
                    Icons.error,
                    color: kcPrimaryColor,
                  );
                } else {
                  return displaysimpleprogress(context);
                }
              },
            )
          ],
        ),
      ),
      drawer: drawer(context, viewModel),
      appBar: AppBar(
        title: Column(
          children: [
            topdata(viewModel.sharedpref.readString('name').toUpperCase(),
                Icons.person, true, fontSize14),
            topdata(viewModel.sharedpref.readString('address'),
                Icons.not_listed_location, false, fontSize12),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(50),
              child: CachedNetworkImage(
                imageUrl: viewModel.sharedpref.readString('img'),
                imageBuilder: (context, imageProvider) => Container(
                  width: screenWidthCustom(context, 0.1),
                  height: screenWidthCustom(context, 0.1),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: imageProvider,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                placeholder: (context, url) => const CircularProgressIndicator(
                  color: kcPrimaryColorlight,
                ),
                errorWidget: (context, url, error) => const Icon(
                  Icons.error,
                  color: white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget transferscreen(
      String img, BuildContext context, String data, void Function() function) {
    return InkWell(
      onTap: () => function(),
      child: Container(
        padding: const EdgeInsets.all(10),
        margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                  color: getColorWithOpacity(kcVeryLightGrey, 0.5),
                  spreadRadius: 2,
                  blurRadius: 2,
                  offset: const Offset(0, 2))
            ],
            color: white),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Image.asset(
                img,
                width: screenWidthCustom(context, 0.08),
                height: screenWidthCustom(context, 0.08),
              ),
            ),
            text_helper(
                data: data,
                font: roboto,
                color: kcPrimaryColor,
                size: fontSize12),
          ],
        ),
      ),
    );
  }

  Widget div(String d, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          text_helper(
              data: d,
              font: poppins,
              bold: true,
              color: kcDarkGreyColor,
              size: fontSize14),
          horizontalSpaceSmall,
          Image.asset(
            'assets/fire.png',
            width: screenWidthCustom(context, 0.07),
          )
        ],
      ),
    );
  }

  Widget actions(BuildContext context, void Function() function,
      IconData iconData, String txt) {
    return InkWell(
        onTap: () => function(),
        child: Container(
          padding: const EdgeInsets.all(5),
          margin: const EdgeInsets.all(5),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5), color: kcPrimaryColor),
          child: Row(
            children: [
              Icon(
                iconData,
                color: white,
              ),
              horizontalSpaceSmall,
              text_helper(
                data: txt,
                font: poppins,
                color: white,
                size: fontSize14,
                bold: true,
              )
            ],
          ),
        ));
  }

  Widget listdata(Map e, HomeViewModel viewModel, BuildContext context) {
    return Container(
      width: screenWidth(context),
      height: 200,
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      child: Column(
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            text_helper(
                                data: e['cat'],
                                font: poppins,
                                color: kcPrimaryColorlight,
                                size: fontSize12),
                            text_helper(
                                data: e['itemname'],
                                bold: true,
                                font: poppins,
                                color: kcDarkGreyColor,
                                size: fontSize14),
                            text_helper(
                              data: e['itemdes'],
                              textAlign: TextAlign.start,
                              font: poppins,
                              color: kcDarkGreyColor,
                              size: fontSize10,
                            ),
                          ],
                        ),
                      ),
                      text_helper(
                          data: 'starting from ' + e['itemprice'],
                          font: poppins,
                          color: kcDarkGreyColor,
                          size: fontSize12),
                      AnimatedRatingStars(
                        initialRating: int.parse(e['itemrating']) /
                            int.parse(e['itemuser']),
                        minRating: 0.0,
                        maxRating: 5.0,
                        filledColor: Colors.amber,
                        emptyColor: Colors.grey,
                        filledIcon: Icons.star,
                        halfFilledIcon: Icons.star_half,
                        emptyIcon: Icons.star_border,
                        onChanged: (double rating) {},
                        displayRatingValue: true,
                        interactiveTooltips: true,
                        customFilledIcon: Icons.star,
                        customHalfFilledIcon: Icons.star_half,
                        customEmptyIcon: Icons.star_border,
                        starSize: 20,
                        animationDuration: const Duration(milliseconds: 300),
                        animationCurve: Curves.easeInOut,
                        readOnly: true,
                      ),
                    ],
                  ),
                ),
                SizedBox(
                    width: screenWidthCustom(context, 0.4),
                    child: Customslider(data: e['image'])),
              ],
            ),
          ),
          verticalSpaceSmall,
          Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: () => viewModel.next(),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: kcPrimaryColor,
                    ),
                    child: text_helper(
                        data: "Order Now",
                        font: poppins,
                        color: white,
                        size: fontSize14,
                        bold: true),
                  ),
                ),
              ),
              horizontalSpaceTiny,
              Expanded(
                child: InkWell(
                  onTap: () => viewModel.reviws(e),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: kcPrimaryColor,
                    ),
                    child: text_helper(
                        data: "Check Reviews",
                        font: poppins,
                        color: white,
                        size: fontSize14,
                        bold: true),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    ).animate(delay: 500.milliseconds).fade().moveY(begin: 50, end: 0);
  }

  Widget topdata(String data, IconData iconData, bool bold, double font) {
    return Row(
      children: [
        horizontalSpaceTiny,
        text_helper(
          data: data,
          font: montserrat,
          color: kcDarkGreyColor,
          size: font,
          bold: bold,
        ),
      ],
    );
  }

  Drawer drawer(BuildContext context, HomeViewModel viewModel) {
    return Drawer(
      child: Column(
        children: <Widget>[
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Lottie.asset('assets/loading.json',
                    width: screenWidthCustom(context, 0.4),
                    height: screenWidthCustom(context, 0.4)),
                text_helper(
                    data: "Dynsynce",
                    font: poppins,
                    bold: true,
                    color: kcDarkGreyColor,
                    size: fontSize18)
              ],
            ),
          ),
          Expanded(
            child: Column(
              children: [
                actions(
                    context, viewModel.orders, Icons.bookmark_border, 'Orders'),
                actions(context, viewModel.wallet, Icons.wallet, 'Wallet'),
                actions(context, () => viewModel.complaint(context),
                    Icons.compare_outlined, 'Complaint'),
                actions(context, () => viewModel.gift(), Icons.card_giftcard,
                    'Virtual Gift'),
                actions(context, () => viewModel.chat(), Icons.chat, 'Chat'),
                actions(context, viewModel.login, Icons.logout, 'Logout'),
              ],
            ),
          )
        ],
      ),
    );
  }

  @override
  HomeViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      HomeViewModel();
}
