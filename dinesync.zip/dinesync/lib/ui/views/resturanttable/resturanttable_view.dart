import 'dart:developer';

import 'package:dinesync/ui/common/apihelpers/apihelper.dart';
import 'package:dinesync/ui/common/app_colors.dart';
import 'package:dinesync/ui/common/app_strings.dart';
import 'package:dinesync/ui/common/ui_helpers.dart';
import 'package:dinesync/ui/common/uihelper/button_helper.dart';
import 'package:dinesync/ui/common/uihelper/text_helper.dart';
import 'package:dinesync/ui/widgets/common/selectcustomer/selectcustomer.dart';
import 'package:dinesync/ui/widgets/common/top/top.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:stacked/stacked.dart';

import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_veiw_helper.dart';
import 'resturanttable_viewmodel.dart';

class ResturanttableView extends StackedView<ResturanttableViewModel> {
  ResturanttableView({Key? key, required this.user}) : super(key: key);
  bool user;

  @override
  Widget builder(
    BuildContext context,
    ResturanttableViewModel viewModel,
    Widget? child,
  ) {
    viewModel.first(context);
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Top(
                      txt: user ? "Select Table" : "Table Management",
                      iconData: Icons.table_bar_outlined),
                ),
                user
                    ? const SizedBox.shrink()
                    : InkWell(
                        onTap: () {
                          historydialog(context, viewModel);
                        },
                        child: const Icon(Icons.history)),
                horizontalSpaceSmall,
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                InkWell(
                    onTap: () => viewModel.selectDate(context),
                    child: top(context, "Date", viewModel.date)),
                InkWell(
                    onTap: () => viewModel.selectTime(context, true),
                    child: top(context, "time start", viewModel.times)),
                InkWell(
                    // onTap: () => viewModel.selectTime(context, false),
                    child: top(context, "time end", viewModel.timee)),
              ],
            ),
            verticalSpaceTiny,
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: FutureBuilder(
                  future: ApiHelper.getalltable(
                      '0000-0000000',
                      viewModel.sharedpref.readString('number'),
                      viewModel.date,
                      viewModel.times,
                      viewModel.timee),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData) {
                      return GridView.builder(
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 10),
                        itemCount: snapshot.data.length,
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                            onTap: () {
                              if (!user) {
                                viewModel.update(snapshot.data[index] as Map);
                                tablesheet(context, viewModel);
                              } else {
                                if (!snapshot.data[index]['exist']) {
                                  customerdialog(
                                      context,
                                      "t${index + 1}",
                                      int.parse(snapshot.data[index]['people']),
                                      viewModel);
                                } else {
                                  show_snackbar(context, "Already Booked");
                                }
                              }
                            },
                            child: Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: snapshot.data[index]['exist']
                                    ? kcPrimaryColorlight
                                    : white,
                                boxShadow: [
                                  BoxShadow(
                                      offset: const Offset(2, 2),
                                      blurRadius: 2,
                                      spreadRadius: 2,
                                      color:
                                          getColorWithOpacity(kcLightGrey, 0.2))
                                ],
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Row(
                                        children: [
                                          const Icon(Icons.person),
                                          text_helper(
                                            data: snapshot.data[index]
                                                ['people'],
                                            font: poppins,
                                            color: kcDarkGreyColor,
                                            size: fontSize16,
                                          ),
                                        ],
                                      ),
                                      text_helper(
                                        data: "t${index + 1}",
                                        font: poppins,
                                        color: kcDarkGreyColor,
                                        size: fontSize16,
                                        bold: true,
                                      ),
                                    ],
                                  ),
                                  Image.asset(
                                    'assets/dish.png',
                                    width: screenWidthCustom(context, 0.2),
                                    height: screenHeightCustom(context, 0.05),
                                  ),
                                  text_helper(
                                    data: snapshot.data[index]['des'],
                                    font: poppins,
                                    color: kcDarkGreyColor,
                                    size: fontSize12,
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcPrimaryColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              ),
            )
          ],
        ),
      ),
      floatingActionButton: user
          ? const SizedBox.shrink()
          : FloatingActionButton(
              onPressed: () {
                tablesheet(context, viewModel);
              },
              backgroundColor: kcPrimaryColor,
              child: const Icon(
                Icons.add,
                color: white,
                size: 30,
              ),
            ),
    );
  }

  Widget top(BuildContext context, String title, String des) {
    return Container(
      padding: const EdgeInsets.all(5),
      margin: const EdgeInsets.all(5),
      width: screenWidthCustom(context, 0.3),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5), color: kcVeryLightGrey),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          text_helper(
            data: title,
            font: poppins,
            color: kcDarkGreyColor,
            size: fontSize14,
            bold: true,
          ),
          text_helper(
              data: des,
              font: poppins,
              color: kcDarkGreyColor,
              size: fontSize12)
        ],
      ),
    );
  }

  void tablesheet(BuildContext context, ResturanttableViewModel viewModel) {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return Container(
            width: screenWidth(context),
            height: screenHeightCustom(context, 0.7),
            color: white,
            child: Column(
              children: [
                text_view_helper(
                  hint: "Enter table Description",
                  controller: viewModel.des,
                  showicon: true,
                  icon: const Icon(Icons.table_bar_outlined),
                )
                    .animate(delay: 500.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
                text_view_helper(
                  hint: "Enter Number Of peoples",
                  controller: viewModel.people,
                  showicon: true,
                  icon: const Icon(Icons.table_bar_outlined),
                )
                    .animate(delay: 700.milliseconds)
                    .fade()
                    .moveY(begin: 50, end: 0),
                viewModel.id == ''
                    ? button_helper(
                            onpress: () => viewModel.add(context),
                            color: kcPrimaryColorlight,
                            width: screenWidthCustom(context, 0.25),
                            child: text_helper(
                                data: "Add",
                                font: roboto,
                                bold: true,
                                color: white,
                                size: fontSize16))
                        .animate(delay: 900.milliseconds)
                        .fade()
                        .moveY(begin: 50, end: 0)
                    : Row(
                        children: [
                          button_helper(
                                  onpress: () => viewModel.delete(context),
                                  color: kcPrimaryColorDark,
                                  width: screenWidthCustom(context, 0.25),
                                  child: text_helper(
                                      data: "Delete",
                                      font: roboto,
                                      bold: true,
                                      color: white,
                                      size: fontSize16))
                              .animate(delay: 900.milliseconds)
                              .fade()
                              .moveY(begin: 50, end: 0),
                          button_helper(
                                  onpress: () =>
                                      viewModel.updateactual(context),
                                  color: kcPrimaryColorlight,
                                  width: screenWidthCustom(context, 0.25),
                                  child: text_helper(
                                      data: "Update",
                                      font: roboto,
                                      bold: true,
                                      color: white,
                                      size: fontSize16))
                              .animate(delay: 900.milliseconds)
                              .fade()
                              .moveY(begin: 50, end: 0),
                        ],
                      ),
              ],
            ),
          );
        });
  }

  void customerdialog(BuildContext context, String table, int people,
      ResturanttableViewModel viewModel) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Selectcustomer(
            table: table,
            people: people,
            date: viewModel.date,
            timee: viewModel.timee,
            times: viewModel.times,
          );
        });
  }

  void historydialog(BuildContext context, ResturanttableViewModel viewModel) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: white,
              ),
              child: FutureBuilder(
                future: ApiHelper.getbyrest(
                    viewModel.sharedpref.readString('number')),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data.toString() == '[]') {
                      return Center(
                        child: text_helper(
                            data: "No Data",
                            font: poppins,
                            color: kcDarkGreyColor,
                            size: fontSize14),
                      );
                    } else {
                      return ListView.builder(
                        itemCount: snapshot.data['rest'].length,
                        itemBuilder: (BuildContext context, int index) {
                          DateTime dateFromString = DateTime.parse(snapshot.data['rest'][index]["datetime"]);
                          DateTime currentDate = DateTime.now();
                          int comparisonResult = dateFromString.compareTo(currentDate);
                          if (comparisonResult < 0) {
                            return const SizedBox.shrink();
                          } else {
                            return Container(
                              padding: const EdgeInsets.all(10),
                              margin: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: getColorWithOpacity(kcLightGrey, 0.2),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      const Icon(Icons.table_bar),
                                      horizontalSpaceSmall,
                                      text_helper(
                                        data: snapshot.data['rest'][index]
                                        ["table"],
                                        font: poppins,
                                        color: kcDarkGreyColor,
                                        size: fontSize14,
                                        bold: true,
                                      ),
                                    ],
                                  ),
                                  text_helper(
                                    data: 'Booked Member : ' +
                                        snapshot.data['rest'][index]["family"],
                                    font: poppins,
                                    color: kcDarkGreyColor,
                                    size: fontSize12,
                                  ),
                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.calendar_month,
                                        size: 18,
                                      ),
                                      horizontalSpaceSmall,
                                      text_helper(
                                        data: snapshot.data['rest'][index]
                                        ["datetime"],
                                        font: poppins,
                                        color: kcDarkGreyColor,
                                        size: fontSize10,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      const Icon(Icons.timelapse, size: 18),
                                      horizontalSpaceSmall,
                                      text_helper(
                                        data: snapshot.data['rest'][index]
                                        ["timee"] +
                                            " - " +
                                            snapshot
                                                .data['rest'][index]["times"],
                                        font: poppins,
                                        color: kcDarkGreyColor,
                                        size: fontSize10,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          }
                        },
                      );
                    }
                  } else if (snapshot.hasError) {
                    return const Icon(
                      Icons.error,
                      color: kcDarkGreyColor,
                    );
                  } else {
                    return displaysimpleprogress(context);
                  }
                },
              ),
            ),
          );
        });
  }

  @override
  ResturanttableViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      ResturanttableViewModel();
}
