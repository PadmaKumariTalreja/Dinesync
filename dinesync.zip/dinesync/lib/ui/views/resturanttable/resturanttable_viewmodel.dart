// ignore_for_file: use_build_context_synchronously

import 'package:dinesync/ui/common/uihelper/snakbar_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../services/sharedpref_service.dart';
import '../../common/apihelpers/apihelper.dart';

class ResturanttableViewModel extends BaseViewModel {
  TextEditingController des = TextEditingController();
  TextEditingController people = TextEditingController();

  final sharedpref = locator<SharedprefService>();

  String date = DateTime.now().toLocal().toLocal().toString().split(' ')[0];
  String times = '';
  String timee = '';

  bool c = true;
  void first(BuildContext context) {
    if (c) {
      times = TimeOfDay.now().format(context);
      timee = TimeOfDay(
          hour: TimeOfDay
              .now()
              .hour + 1, minute: TimeOfDay
          .now()
          .minute)
          .format(context);
      c = false;
    }
  }

  Future<void> selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (pickedDate != null) {
      date = pickedDate.toLocal().toLocal().toString().split(' ')[0];
      notifyListeners();
    }
  }

  Future<void> selectTime(BuildContext context, bool c) async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (pickedTime != null) {
      if (c) {
        times = pickedTime.format(context);
        timee = TimeOfDay(
            hour: pickedTime.hour + 2,
            minute: pickedTime.minute)
            .format(context);
      } else {
        timee = pickedTime.format(context);
      }
      notifyListeners();
    }
  }

  Future<void> add(BuildContext context) async {
    if (des.text.isEmpty || people.text.isEmpty) {
      show_snackbar(context, "Enter data");
    } else {
      displayprogress(context);
      bool check = await ApiHelper.tableregistration(
          sharedpref.readString('number'), people.text, des.text, context);
      if (check) {
        hideprogress(context);
        clearall(context);
      } else {
        hideprogress(context);
      }
    }
  }

  Future<void> updateactual(BuildContext context) async {
    if (des.text.isEmpty || people.text.isEmpty) {
      show_snackbar(context, "Enter data");
    } else {
      displayprogress(context);
      bool check =
          await ApiHelper.updatetable(id, people.text, des.text, context);
      if (check) {
        hideprogress(context);
        clearall(context);
      } else {
        hideprogress(context);
      }
    }
  }

  String id = '';

  void update(Map data) {
    people.text = data['people'];
    des.text = data['des'];
    id = data['_id'];
    notifyListeners();
  }

  void clearall(BuildContext context) {
    people.clear();
    des.clear();
    id = '';
    notifyListeners();
    Navigator.pop(context);
  }

  Future<void> delete(BuildContext context) async {
    displayprogress(context);
    await ApiHelper.deletetable(id, context);
    hideprogress(context);
    clearall(context);
  }
}
