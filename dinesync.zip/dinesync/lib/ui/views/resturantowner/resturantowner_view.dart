import 'dart:ui';

import 'package:dinesync/ui/common/app_colors.dart';
import 'package:dinesync/ui/common/app_strings.dart';
import 'package:dinesync/ui/common/ui_helpers.dart';
import 'package:dinesync/ui/common/uihelper/snakbar_helper.dart';
import 'package:dinesync/ui/common/uihelper/text_helper.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import 'resturantowner_viewmodel.dart';

class ResturantownerView extends StackedView<ResturantownerViewModel> {
  const ResturantownerView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    ResturantownerViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      appBar: AppBar(
        backgroundColor: kcPrimaryColor,
        title: text_helper(
            data: "Admin View",
            font: poppins,
            bold: true,
            color: white,
            size: fontSize14),
        actions: [
          // InkWell(
          //     onTap: () => viewModel.restcomplete(),
          //     child: const Icon(Icons.settings)),
          InkWell(
              onTap: () => viewModel.login(),
              child: const Padding(
                padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                child: Icon(
                  Icons.logout,
                  color: white,
                ),
              ))
        ],
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Opacity(
              opacity: 0.3,
              child: ImageFiltered(
                imageFilter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
                child: Image.asset(
                  "assets/rest.jpg",
                  width: double.infinity,
                  height: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    transferscreen(
                        'assets/table.png', context, 'Table', viewModel.table),
                    transferscreen(
                        'assets/menu.png', context, 'menu', viewModel.menu),
                  ],
                ),
                Row(
                  children: [
                    transferscreen('assets/orders.png', context, 'order',
                        viewModel.orders),
                    transferscreen('assets/wallet.png', context, 'wallet',
                        viewModel.wallet),
                  ],
                ),
                Row(
                  children: [
                    transferscreen('assets/ana.png', context, 'Analytics',
                        viewModel.analytics),
                    transferscreen('assets/complaint.png', context, 'Complaint',
                        () {
                      showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return Dialog(
                              backgroundColor: white,
                              child: Container(
                                padding: const EdgeInsets.all(10),
                                width: screenWidth(context),
                                color: white,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    text_helper(
                                        data: 'Complaint',
                                        font: poppins,
                                        bold: true,
                                        color: kcPrimaryColor,
                                        size: fontSize18),
                                    Expanded(
                                      child: FutureBuilder(
                                        future: ApiHelper.allcomplaint(),
                                        builder: (BuildContext context,
                                            AsyncSnapshot snapshot) {
                                          if (snapshot.hasData) {
                                            if (snapshot.data.toString() ==
                                                '[]') {
                                              return Center(
                                                child: text_helper(
                                                    data: "No Data",
                                                    font: poppins,
                                                    color: kcDarkGreyColor,
                                                    size: fontSize14),
                                              );
                                            } else {
                                              return ListView.builder(
                                                shrinkWrap: true,
                                                itemCount: snapshot.data.length,
                                                itemBuilder:
                                                    (BuildContext context,
                                                        int index) {
                                                  return Container(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            10),
                                                    margin:
                                                        const EdgeInsets.all(
                                                            10),
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        color:
                                                            getColorWithOpacity(
                                                                kcVeryLightGrey,
                                                                0.2)),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        text_helper(
                                                            data: snapshot
                                                                    .data[index]
                                                                ['title'],
                                                            bold: true,
                                                            font: poppins,
                                                            color:
                                                                kcDarkGreyColor,
                                                            size: fontSize16),
                                                        text_helper(
                                                            data: snapshot
                                                                    .data[index]
                                                                ['des'],
                                                            font: poppins,
                                                            color:
                                                                kcDarkGreyColor,
                                                            size: fontSize14),
                                                      ],
                                                    ),
                                                  );
                                                },
                                              );
                                            }
                                          } else if (snapshot.hasError) {
                                            return const Icon(
                                              Icons.error,
                                              color: kcDarkGreyColor,
                                            );
                                          } else {
                                            return displaysimpleprogress(
                                                context);
                                          }
                                        },
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            );
                          });
                    }),
                  ],
                ),
                Row(
                  children: [
                    transferscreen(
                        'assets/gift.png', context, 'Gifts', viewModel.gift),
                    transferscreen('assets/chats.png', context, 'All Chats',
                        viewModel.allchats),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget transferscreen(
      String img, BuildContext context, String data, void Function() function) {
    return Expanded(
      child: InkWell(
        onTap: () => function(),
        child: Container(
          padding: const EdgeInsets.all(10),
          margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                    color: getColorWithOpacity(kcVeryLightGrey, 0.5),
                    spreadRadius: 2,
                    blurRadius: 2,
                    offset: const Offset(0, 2))
              ],
              color: white),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              verticalSpaceSmall,
              Image.asset(
                img,
                width: screenWidthCustom(context, 0.12),
                height: screenWidthCustom(context, 0.12),
              ),
              verticalSpaceSmall,
              const Divider(
                height: 2,
              ),
              text_helper(
                  data: data,
                  font: roboto,
                  bold: true,
                  color: kcPrimaryColor,
                  size: fontSize14),
              const Divider(
                height: 2,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  ResturantownerViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      ResturantownerViewModel();
}
