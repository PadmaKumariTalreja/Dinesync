import 'package:dinesync/ui/views/analytics/analytics_view.dart';
import 'package:dinesync/ui/views/chat/allchats/allchats_view.dart';
import 'package:dinesync/ui/views/login/login_view.dart';
import 'package:dinesync/ui/views/resturantcomplete/resturantcomplete_view.dart';
import 'package:dinesync/ui/views/resturantmenu/resturantmenu_view.dart';
import 'package:dinesync/ui/views/resturantorder/resturantorder_view.dart';
import 'package:dinesync/ui/views/resturanttable/resturanttable_view.dart';
import 'package:dinesync/ui/views/wallet/wallet_view.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../services/sharedpref_service.dart';
import '../virtualgift/virtualgift_view.dart';

class ResturantownerViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();
  final sharedpref = locator<SharedprefService>();

  void login() {
    sharedpref.remove('name');
    sharedpref.remove('cnic');
    sharedpref.remove('number');
    sharedpref.remove('address');
    sharedpref.remove('dob');
    sharedpref.remove('cat');
    sharedpref.remove('img');
    _navigationService.clearStackAndShow(Routes.loginView);
    _navigationService.replaceWithTransition(const LoginView(),
        routeName: Routes.loginView, transitionStyle: Transition.rightToLeft);
  }

  void table() {
    _navigationService.navigateWithTransition(
        ResturanttableView(
          user: false,
        ),
        routeName: Routes.resturanttableView,
        transitionStyle: Transition.rightToLeft);
  }

  void orders() {
    _navigationService.navigateWithTransition(const ResturantorderView(),
        routeName: Routes.resturantorderView,
        transitionStyle: Transition.rightToLeft);
  }

  void menu() {
    _navigationService.navigateWithTransition(const ResturantmenuView(),
        routeName: Routes.resturantmenuView,
        transitionStyle: Transition.rightToLeft);
  }

  void restcomplete() {
    _navigationService.navigateWithTransition(const ResturantcompleteView(),
        routeName: Routes.resturantcompleteView,
        transitionStyle: Transition.rightToLeft);
  }

  void wallet() {
    _navigationService.navigateWithTransition(const WalletView(),
        routeName: Routes.walletView, transitionStyle: Transition.rightToLeft);
  }

  void analytics() {
    _navigationService.navigateWithTransition(const AnalyticsView(),
        routeName: Routes.analyticsView,
        transitionStyle: Transition.rightToLeft);
  }

  void gift() {
    _navigationService.navigateWithTransition(const VirtualgiftView(),
        routeName: Routes.virtualgiftView,
        transitionStyle: Transition.rightToLeft);
  }

  void allchats() {
    _navigationService.navigateWithTransition(const AllchatsView(),
        routeName: Routes.allchatsView,
        transitionStyle: Transition.rightToLeft);
  }
}
