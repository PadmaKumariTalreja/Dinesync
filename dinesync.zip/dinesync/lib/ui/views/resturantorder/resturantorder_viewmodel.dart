// ignore_for_file: use_build_context_synchronously

import 'package:dinesync/ui/common/apihelpers/apihelper.dart';
import 'package:dinesync/ui/common/apihelpers/firebsaeuploadhelper.dart';
import 'package:dinesync/ui/common/uihelper/snakbar_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../services/sharedpref_service.dart';

class ResturantorderViewModel extends BaseViewModel {
  final sharedpref = locator<SharedprefService>();
  String val = "all";

  Future<void> changestatus(
      BuildContext context, String status, Map data) async {
    await ApiHelper.updatestatus(data["_id"], status, context);
    Map datauu = await ApiHelper.findone(data["custnumber"], context);
    await FirebaseHelper.sendnotificationto(
        datauu['deviceid'], "Order Update", "Order status is $status");
    notifyListeners();
  }

  Future<void> plenty(Map data, BuildContext context) async {
    displayprogress(context);
    Map cw = await ApiHelper.getwallet(data['custnumber']);
    int price = 0;
    List p = data['menu'];
    for (var element in p) {
      price += int.parse(element['editprice']);
    }
    price = (price * 0.3).toInt();
    bool c = await ApiHelper.updatewallet(
        cw['rest']['number'],
        '${int.parse(cw['rest']['notpay']) + price}',
        cw['rest']['paid'],
        cw['rest']['topup'],
        cw['rest']['cbill'],
        context);
    if (c) {
      Map datauu = await ApiHelper.findone(data["custnumber"], context);
      await FirebaseHelper.sendnotificationto(
          datauu['deviceid'], "Order Update", "Plenty Added");
      hideprogress(context);
      show_snackbar(context, 'plenty added');
    } else {
      hideprogress(context);
      show_snackbar(context, 'try again later');
    }
  }
}
