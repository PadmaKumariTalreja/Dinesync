import 'package:dinesync/ui/common/app_colors.dart';
import 'package:dinesync/ui/common/uihelper/button_helper.dart';
import 'package:dinesync/ui/widgets/common/top/top.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/apihelpers/apihelper.dart';
import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/snakbar_helper.dart';
import '../../common/uihelper/text_helper.dart';
import 'resturantorder_viewmodel.dart';

class ResturantorderView extends StackedView<ResturantorderViewModel> {
  const ResturantorderView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    ResturantorderViewModel viewModel,
    Widget? child,
  ) {
    // Navigator.pop(context);
    return Scaffold(
        backgroundColor: white,
        body: SafeArea(
          child: Column(
            children: [
              Top(txt: "Resturant Order", iconData: Icons.bookmark_border),
              Row(children: [
                btn("all", viewModel),
                btn("new", viewModel),
                btn("cancle", viewModel),
                btn("old", viewModel),
              ]),
              Expanded(
                child: FutureBuilder(
                  future: ApiHelper.getbyrest(
                      viewModel.sharedpref.readString('number')),
                  builder: (BuildContext context,
                      AsyncSnapshot<Map<dynamic, dynamic>> snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data!['rest'].length,
                        itemBuilder: (BuildContext context, int index) {
                          if (viewModel.val == 'all') {
                            return listdatamain(
                                context, snapshot, index, viewModel);
                          } else {
                            if (viewModel.val ==
                                snapshot.data!['rest'][index]['status']) {
                              return listdatamain(
                                  context, snapshot, index, viewModel);
                            } else {
                              return const SizedBox.shrink();
                            }
                          }
                        },
                      );
                    } else if (snapshot.hasError) {
                      return const Icon(
                        Icons.error,
                        color: kcDarkGreyColor,
                      );
                    } else {
                      return displaysimpleprogress(context);
                    }
                  },
                ),
              )
            ],
          ),
        ));
  }

  Widget listdatamain(BuildContext context, AsyncSnapshot snapshot, int index,
      ResturantorderViewModel viewModel) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: getColorWithOpacity(skin, 0.3)),
      child: Column(
        children: [
          data(
              "Status :  ", snapshot.data!['rest'][index]['status'].toString()),
          snapshot.data!['rest'][index]['family'].toString() == 'take away'
              ? text_helper(
                  data: "Take Away",
                  font: poppins,
                  color: kcDarkGreyColor,
                  size: fontSize16)
              : data("Person :  ",
                  snapshot.data!['rest'][index]['family'].toString()),
          data(
              "Date :  ", snapshot.data!['rest'][index]['datetime'].toString()),
          snapshot.data!['rest'][index]['family'].toString() == 'take away'
              ? const SizedBox.shrink()
              : data("Table number :  ",
                  snapshot.data!['rest'][index]['table'].toString()),
          snapshot.data!['rest'][index]['family'].toString() != 'take away'
              ? data("Time Start :  ",
                  snapshot.data!['rest'][index]['times'].toString())
              : data("Time :  ",
                  snapshot.data!['rest'][index]['times'].toString()),
          snapshot.data!['rest'][index]['family'].toString() == 'take away'
              ? const SizedBox.shrink()
              : data("Time End :  ",
                  snapshot.data!['rest'][index]['timee'].toString()),
          verticalSpaceTiny,
          Column(
            children: List.of(snapshot.data!['rest'][index]['menu'])
                .map((e) => Container(
                      width: screenWidth(context),
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.only(bottom: 5),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          boxShadow: [
                            BoxShadow(
                                offset: const Offset(0, 0),
                                color: getColorWithOpacity(kcLightGrey, 0.3),
                                spreadRadius: 1,
                                blurRadius: 1)
                          ],
                          color: getColorWithOpacity(skin, 1)),
                      child: Column(
                        children: [
                          data("itemname :  ", e['itemname'].toString()),
                          data("Total price :  ", e['editprice'].toString()),
                          data("Total quantity :  ", e['quantity'].toString()),
                        ],
                      ),
                    ))
                .toList(),
          ),
          snapshot.data!['rest'][index]['status'] != "new"
              ? const SizedBox.shrink()
              : Row(
                  children: [
                    button_helper(
                        onpress: () => viewModel.plenty(
                            snapshot.data!['rest'][index] as Map, context),
                        color: kcPrimaryColor,
                        width: screenWidthCustom(context, 0.2),
                        child: text_helper(
                            data: "plenty",
                            font: poppins,
                            color: white,
                            bold: true,
                            size: fontSize12)),
                    button_helper(
                        onpress: () => viewModel.changestatus(context, "cancle",
                            snapshot.data!['rest'][index] as Map),
                        color: red,
                        width: screenWidthCustom(context, 0.2),
                        child: text_helper(
                            data: "cancle",
                            font: poppins,
                            color: white,
                            bold: true,
                            size: fontSize12)),
                    button_helper(
                        onpress: () => viewModel.changestatus(context, "old",
                            snapshot.data!['rest'][index] as Map),
                        color: green,
                        width: screenWidthCustom(context, 0.2),
                        child: text_helper(
                            data: "done",
                            font: poppins,
                            color: white,
                            bold: true,
                            size: fontSize12)),
                  ],
                )
        ],
      ),
    );
  }

  Widget data(String title, String des) {
    return Row(
      children: [
        text_helper(
          data: title,
          bold: true,
          font: poppins,
          color: kcPrimaryColor,
          size: fontSize12,
        ),
        text_helper(
          data: des,
          font: poppins,
          color: kcDarkGreyColor,
          size: fontSize12,
        ),
      ],
    );
  }

  Widget data2(String title, String des) {
    return Row(
      children: [
        text_helper(
          data: title,
          bold: true,
          font: poppins,
          color: white,
          size: fontSize12,
        ),
        text_helper(
          data: des,
          font: poppins,
          color: white,
          size: fontSize12,
        ),
      ],
    );
  }

  Widget btn(String title, ResturantorderViewModel viewModel) {
    return InkWell(
      onTap: () {
        viewModel.val = title;
        viewModel.notifyListeners();
      },
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
        margin: const EdgeInsets.all(5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              width: 1,
              color: kcPrimaryColor,
            ),
            color: viewModel.val == title
                ? kcPrimaryColor
                : getColorWithOpacity(kcVeryLightGrey, 0.3)),
        child: text_helper(
            data: title,
            font: montserrat,
            color: viewModel.val != title ? kcPrimaryColor : white,
            size: fontSize14,
            bold: true),
      ),
    );
  }

  @override
  ResturantorderViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      ResturantorderViewModel();
}
