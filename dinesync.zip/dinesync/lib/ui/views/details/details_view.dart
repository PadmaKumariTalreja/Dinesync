import 'package:dinesync/ui/common/app_colors.dart';
import 'package:dinesync/ui/common/uihelper/button_helper.dart';
import 'package:dinesync/ui/common/uihelper/text_veiw_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_strings.dart';
import '../../common/ui_helpers.dart';
import '../../common/uihelper/text_helper.dart';
import 'details_viewmodel.dart';

class DetailsView extends StackedView<DetailsViewModel> {
  const DetailsView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    DetailsViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  text_helper(
                    data: "Enter Details",
                    font: poppins,
                    color: kcPrimaryColor,
                    size: fontSize22,
                    bold: true,
                  ),
                  SizedBox(
                      width: screenWidthCustom(context, 0.2),
                      height: screenWidthCustom(context, 0.2),
                      child: Lottie.asset('assets/loading.json')),
                ],
              ).animate(delay: 500.milliseconds).fade(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    text_view_helper(
                      hint: "Enter name",
                      controller: viewModel.name,
                      formatter: [
                        FilteringTextInputFormatter.allow(getRegExpstring())
                      ],
                      showicon: true,
                    )
                        .animate(delay: 700.milliseconds)
                        .fade()
                        .moveY(begin: 50, end: 0),
                    text_view_helper(
                      hint: "Enter number",
                      controller: viewModel.number,
                      showicon: true,
                      icon: const Icon(Icons.call),
                      maxlength: 11,
                      formatter: [
                        FilteringTextInputFormatter.allow(getRegExpint())
                      ],
                      textInputType: TextInputType.phone,
                    )
                        .animate(delay: 900.milliseconds)
                        .fade()
                        .moveY(begin: 50, end: 0),
                    text_view_helper(
                      hint: "Enter cnic",
                      controller: viewModel.cnic,
                      showicon: true,
                      icon: const Icon(Icons.dock),
                      maxlength: 13,
                      formatter: [
                        FilteringTextInputFormatter.allow(getRegExpint())
                      ],
                      textInputType: TextInputType.phone,
                    )
                        .animate(delay: 1100.milliseconds)
                        .fade()
                        .moveY(begin: 50, end: 0),
                    text_view_helper(
                            hint: "House No, Block, Sector/Town, City",
                            controller: viewModel.address,
                            showicon: true,
                            icon: const Icon(Icons.home))
                        .animate(delay: 1300.milliseconds)
                        .fade()
                        .moveY(begin: 50, end: 0),
                    InkWell(
                      onTap: () => viewModel.selectdob(context),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: text_helper(
                            data: viewModel.dob.text == ''
                                ? "Select Date of Birth"
                                : viewModel.dob.text,
                            font: poppins,
                            color: kcDarkGreyColor,
                            size: fontSize14),
                      ),
                    )
                        .animate(delay: 1500.milliseconds)
                        .fade()
                        .moveY(begin: 50, end: 0)
                  ],
                ),
              ),
              button_helper(
                      onpress: () => viewModel.next(context),
                      color: kcPrimaryColorlight,
                      width: screenWidthCustom(context, 0.3),
                      child: text_helper(
                          data: "Next",
                          font: poppins,
                          color: white,
                          bold: true,
                          size: fontSize18))
                  .animate(delay: 1700.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
              InkWell(
                onTap: () => viewModel.login(),
                child: text_helper(
                  data: "Already Have Account",
                  font: poppins,
                  color: kcPrimaryColor,
                  size: fontSize12,
                ),
              )
                  .animate(delay: 1900.milliseconds)
                  .fade()
                  .moveY(begin: 50, end: 0),
            ],
          ),
        ),
      ),
    );
  }

  @override
  DetailsViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      DetailsViewModel();
}
