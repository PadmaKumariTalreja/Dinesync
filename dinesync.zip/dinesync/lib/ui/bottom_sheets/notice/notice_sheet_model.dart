import 'package:stacked/stacked.dart';

class NoticeSheetModel extends BaseViewModel {}
