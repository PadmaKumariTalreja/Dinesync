// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/app_strings.dart';
import '../../../common/ui_helpers.dart';
import '../../../common/uihelper/text_helper.dart';
import 'top_model.dart';

class Top extends StackedView<TopModel> {
  Top({super.key, required this.txt, required this.iconData});
  String txt;
  IconData iconData;

  @override
  Widget builder(
    BuildContext context,
    TopModel viewModel,
    Widget? child,
  ) {
    return Container(
      width: screenWidth(context),
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.all(10),
      child: Row(
        children: [
          InkWell(
              onTap: () => viewModel.back(),
              child: const Icon(
                Icons.arrow_back,
                color: kcPrimaryColor,
              )),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  iconData,
                  color: kcPrimaryColorDark,
                ),
                horizontalSpaceSmall,
                text_helper(
                  data: txt,
                  font: poppins,
                  textAlign: TextAlign.start,
                  color: kcPrimaryColorDark,
                  size: fontSize16,
                  bold: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  TopModel viewModelBuilder(
    BuildContext context,
  ) =>
      TopModel();
}
