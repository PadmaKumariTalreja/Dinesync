import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/app_strings.dart';
import '../../../common/ui_helpers.dart';
import '../../../common/uihelper/button_helper.dart';
import '../../../common/uihelper/text_helper.dart';
import 'selectcustomer_model.dart';

class Selectcustomer extends StackedView<SelectcustomerModel> {
  Selectcustomer(
      {super.key,
      required this.table,
      required this.people,
      required this.date,
      required this.timee,
      required this.times});
  String table, date, times, timee;
  int people;

  @override
  Widget builder(
    BuildContext context,
    SelectcustomerModel viewModel,
    Widget? child,
  ) {
    return FractionallySizedBox(
      heightFactor: 0.5,
      child: Container(
        width: screenWidth(context),
        height: screenHeightCustom(context, 0.2),
        margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10), color: white),
        child: Material(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              verticalSpaceSmall,
              text_helper(
                  data: "Select Customer Count",
                  font: poppins,
                  bold: true,
                  color: kcDarkGreyColor,
                  size: fontSize18),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/dish.png',
                    width: screenWidthCustom(context, 0.1),
                    height: screenWidthCustom(context, 0.1),
                  ),
                  horizontalSpaceSmall,
                  text_helper(
                      data: table,
                      font: poppins,
                      color: kcDarkGreyColor,
                      size: fontSize12)
                ],
              ),
              Expanded(
                  child: Wrap(
                spacing: 16.0, // Adjust the spacing between buttons as needed
                children: List.generate(
                    people, (index) => btn('${index + 1}', context, viewModel)),
              )),
              button_helper(
                  onpress: () => viewModel.menu(date, times, timee),
                  color: kcDarkGreyColor,
                  raduis: 0,
                  margin: const EdgeInsetsDirectional.all(0),
                  width: screenWidth(context),
                  child: text_helper(
                      data: "Select Menu",
                      font: poppins,
                      bold: true,
                      color: white,
                      size: fontSize14))
            ],
          ),
        ),
      ),
    );
  }

  Widget btn(
      String number, BuildContext context, SelectcustomerModel viewModel) {
    return InkWell(
      onTap: () {
        viewModel.customer = number;
        viewModel.notifyListeners();
      },
      child: Container(
        width: screenWidthCustom(context, 0.1),
        height: screenWidthCustom(context, 0.1),
        padding: const EdgeInsets.all(5),
        margin: const EdgeInsets.all(5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: viewModel.customer == number ? kcDarkGreyColor : white,
            boxShadow: [
              BoxShadow(
                  offset: const Offset(2, 2),
                  blurRadius: 2,
                  spreadRadius: 2,
                  color: getColorWithOpacity(kcLightGrey, 0.2))
            ]),
        child: Center(
          child: text_helper(
              data: number,
              font: poppins,
              color: viewModel.customer == number ? white : kcDarkGreyColor,
              size: fontSize14),
        ),
      ),
    );
  }

  @override
  void onViewModelReady(SelectcustomerModel viewModel) {
    viewModel.table = table;
  }

  @override
  SelectcustomerModel viewModelBuilder(
    BuildContext context,
  ) =>
      SelectcustomerModel();
}
