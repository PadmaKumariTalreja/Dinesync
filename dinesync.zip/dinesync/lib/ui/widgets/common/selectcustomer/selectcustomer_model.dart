import 'package:dinesync/ui/views/userresturantview/userresturantview_view.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../../app/app.locator.dart';
import '../../../../app/app.router.dart';

class SelectcustomerModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();

  String table = '';

  String customer = '';
  void menu(date, times, timee) {
    _navigationService.back();
    _navigationService.navigateWithTransition(
        UserresturantviewView(
            table: table,
            people: customer,
            date: date,
            timee: timee,
            times: times),
        routeName: Routes.userresturantviewView,
        transitionStyle: Transition.rightToLeft);
  }
}
