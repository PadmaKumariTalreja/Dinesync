// ignore_for_file: use_build_context_synchronously

import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:image_picker/image_picker.dart';
import 'package:stacked/stacked.dart';

import '../../../../app/app.locator.dart';
import '../../../../services/sharedpref_service.dart';
import '../../../common/apihelpers/apihelper.dart';
import '../../../common/apihelpers/firebsaeuploadhelper.dart';
import '../../../common/uihelper/snakbar_helper.dart';

class AddmenuModel extends BaseViewModel {
  TextEditingController itemname = TextEditingController();
  TextEditingController itemprice = TextEditingController();
  TextEditingController itemdes = TextEditingController();

  final sharedpref = locator<SharedprefService>();

  String cats = 'Chinees';
  String mcats = 'Appetizers';

  List<XFile> selectedImages = [];

  Future<void> pickImages() async {
    final picker = ImagePicker();
    final pickedImages = await picker.pickMultiImage(
      imageQuality: 10,
    );
    selectedImages = pickedImages;
    notifyListeners();
  }

  List fimages = [];
  String id = '';

  Future<void> add(BuildContext context) async {
    if (itemname.text.isEmpty ||
        itemprice.text.isEmpty ||
        itemdes.text.isEmpty) {
      show_snackbar(context, "Enter data");
    } else {
      displayprogress(context);
      List<String> finalimages = [];
      for (var element in selectedImages) {
        finalimages.add(await FirebaseHelper.uploadFile(
            File(element.path), sharedpref.readString("number")));
      }
      bool check = await ApiHelper.menuregistration(
          sharedpref.readString('number'),
          itemname.text,
          itemprice.text,
          itemdes.text,
          finalimages,
          cats,
          mcats,
          context);
      if (check) {
        hideprogress(context);
        clearall(context);
      } else {
        hideprogress(context);
      }
    }
  }

  Future<void> updateactual(BuildContext context) async {
    if (itemname.text.isEmpty ||
        itemprice.text.isEmpty ||
        itemdes.text.isEmpty) {
      show_snackbar(context, "Enter data");
    } else {
      displayprogress(context);
      List<String> finalimages = [];
      for (var i in fimages) {
        finalimages.add(i);
      }
      for (var element in selectedImages) {
        finalimages.add(await FirebaseHelper.uploadFile(
            File(element.path), sharedpref.readString("number")));
      }
      bool check = await ApiHelper.updatemenu(id, itemname.text, itemprice.text,
          itemdes.text, finalimages, cats, mcats, context);
      if (check) {
        hideprogress(context);
        clearall(context);
      } else {
        hideprogress(context);
      }
    }
  }

  void clearall(BuildContext context) {
    itemdes.clear();
    itemprice.clear();
    itemname.clear();
    fimages.clear();
    selectedImages.clear();
    notifyListeners();
    Navigator.pop(context);
  }

  void update(Map e) {
    if (e.isNotEmpty) {
      itemname.text = e['itemname'];
      itemprice.text = e['itemprice'];
      itemdes.text = e['itemdes'];
      fimages = List.of(e['image']);
      id = e['_id'];
      cats = e['cat'];
      mcats = e['mcat'];
    }
  }

  Future<void> delete(BuildContext context) async {
    displayprogress(context);
    await ApiHelper.deletemenu(id, context);
    hideprogress(context);
    clearall(context);
  }
}
