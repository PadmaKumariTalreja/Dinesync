// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// StackedNavigatorGenerator
// **************************************************************************

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:dinesync/ui/views/addpass/addpass_view.dart' as _i9;
import 'package:dinesync/ui/views/analytics/analytics_view.dart' as _i19;
import 'package:dinesync/ui/views/booknow/booknow_view.dart' as _i15;
import 'package:dinesync/ui/views/chat/allchats/allchats_view.dart' as _i22;
import 'package:dinesync/ui/views/chat/chating/chating_view.dart' as _i23;
import 'package:dinesync/ui/views/details/details_view.dart' as _i6;
import 'package:dinesync/ui/views/home/home_view.dart' as _i2;
import 'package:dinesync/ui/views/login/login_view.dart' as _i4;
import 'package:dinesync/ui/views/otp/otp_view.dart' as _i7;
import 'package:dinesync/ui/views/pic/pic_view.dart' as _i8;
import 'package:dinesync/ui/views/resturantcomplete/resturantcomplete_view.dart'
    as _i12;
import 'package:dinesync/ui/views/resturantmenu/resturantmenu_view.dart'
    as _i13;
import 'package:dinesync/ui/views/resturantorder/resturantorder_view.dart'
    as _i18;
import 'package:dinesync/ui/views/resturantowner/resturantowner_view.dart'
    as _i10;
import 'package:dinesync/ui/views/resturanttable/resturanttable_view.dart'
    as _i11;
import 'package:dinesync/ui/views/reviews/reviews_view.dart' as _i20;
import 'package:dinesync/ui/views/signup/signup_view.dart' as _i5;
import 'package:dinesync/ui/views/startup/startup_view.dart' as _i3;
import 'package:dinesync/ui/views/usercatview/usercatview_view.dart' as _i24;
import 'package:dinesync/ui/views/userorders/userorders_view.dart' as _i16;
import 'package:dinesync/ui/views/userresturantview/userresturantview_view.dart'
    as _i14;
import 'package:dinesync/ui/views/virtualgift/virtualgift_view.dart' as _i21;
import 'package:dinesync/ui/views/wallet/wallet_view.dart' as _i17;
import 'package:flutter/material.dart' as _i25;
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart' as _i1;
import 'package:stacked_services/stacked_services.dart' as _i26;

class Routes {
  static const homeView = '/home-view';

  static const startupView = '/startup-view';

  static const loginView = '/login-view';

  static const signupView = '/signup-view';

  static const detailsView = '/details-view';

  static const otpView = '/otp-view';

  static const picView = '/pic-view';

  static const addpassView = '/addpass-view';

  static const resturantownerView = '/resturantowner-view';

  static const resturanttableView = '/resturanttable-view';

  static const resturantcompleteView = '/resturantcomplete-view';

  static const resturantmenuView = '/resturantmenu-view';

  static const userresturantviewView = '/userresturantview-view';

  static const booknowView = '/booknow-view';

  static const userordersView = '/userorders-view';

  static const walletView = '/wallet-view';

  static const resturantorderView = '/resturantorder-view';

  static const analyticsView = '/analytics-view';

  static const reviewsView = '/reviews-view';

  static const virtualgiftView = '/virtualgift-view';

  static const allchatsView = '/allchats-view';

  static const chatingView = '/chating-view';

  static const usercatviewView = '/usercatview-view';

  static const all = <String>{
    homeView,
    startupView,
    loginView,
    signupView,
    detailsView,
    otpView,
    picView,
    addpassView,
    resturantownerView,
    resturanttableView,
    resturantcompleteView,
    resturantmenuView,
    userresturantviewView,
    booknowView,
    userordersView,
    walletView,
    resturantorderView,
    analyticsView,
    reviewsView,
    virtualgiftView,
    allchatsView,
    chatingView,
    usercatviewView,
  };
}

class StackedRouter extends _i1.RouterBase {
  final _routes = <_i1.RouteDef>[
    _i1.RouteDef(
      Routes.homeView,
      page: _i2.HomeView,
    ),
    _i1.RouteDef(
      Routes.startupView,
      page: _i3.StartupView,
    ),
    _i1.RouteDef(
      Routes.loginView,
      page: _i4.LoginView,
    ),
    _i1.RouteDef(
      Routes.signupView,
      page: _i5.SignupView,
    ),
    _i1.RouteDef(
      Routes.detailsView,
      page: _i6.DetailsView,
    ),
    _i1.RouteDef(
      Routes.otpView,
      page: _i7.OtpView,
    ),
    _i1.RouteDef(
      Routes.picView,
      page: _i8.PicView,
    ),
    _i1.RouteDef(
      Routes.addpassView,
      page: _i9.AddpassView,
    ),
    _i1.RouteDef(
      Routes.resturantownerView,
      page: _i10.ResturantownerView,
    ),
    _i1.RouteDef(
      Routes.resturanttableView,
      page: _i11.ResturanttableView,
    ),
    _i1.RouteDef(
      Routes.resturantcompleteView,
      page: _i12.ResturantcompleteView,
    ),
    _i1.RouteDef(
      Routes.resturantmenuView,
      page: _i13.ResturantmenuView,
    ),
    _i1.RouteDef(
      Routes.userresturantviewView,
      page: _i14.UserresturantviewView,
    ),
    _i1.RouteDef(
      Routes.booknowView,
      page: _i15.BooknowView,
    ),
    _i1.RouteDef(
      Routes.userordersView,
      page: _i16.UserordersView,
    ),
    _i1.RouteDef(
      Routes.walletView,
      page: _i17.WalletView,
    ),
    _i1.RouteDef(
      Routes.resturantorderView,
      page: _i18.ResturantorderView,
    ),
    _i1.RouteDef(
      Routes.analyticsView,
      page: _i19.AnalyticsView,
    ),
    _i1.RouteDef(
      Routes.reviewsView,
      page: _i20.ReviewsView,
    ),
    _i1.RouteDef(
      Routes.virtualgiftView,
      page: _i21.VirtualgiftView,
    ),
    _i1.RouteDef(
      Routes.allchatsView,
      page: _i22.AllchatsView,
    ),
    _i1.RouteDef(
      Routes.chatingView,
      page: _i23.ChatingView,
    ),
    _i1.RouteDef(
      Routes.usercatviewView,
      page: _i24.UsercatviewView,
    ),
  ];

  final _pagesMap = <Type, _i1.StackedRouteFactory>{
    _i2.HomeView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i2.HomeView(),
        settings: data,
      );
    },
    _i3.StartupView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i3.StartupView(),
        settings: data,
      );
    },
    _i4.LoginView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i4.LoginView(),
        settings: data,
      );
    },
    _i5.SignupView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i5.SignupView(),
        settings: data,
      );
    },
    _i6.DetailsView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i6.DetailsView(),
        settings: data,
      );
    },
    _i7.OtpView: (data) {
      final args = data.getArgs<OtpViewArguments>(nullOk: false);
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => _i7.OtpView(key: args.key, id: args.id),
        settings: data,
      );
    },
    _i8.PicView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i8.PicView(),
        settings: data,
      );
    },
    _i9.AddpassView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i9.AddpassView(),
        settings: data,
      );
    },
    _i10.ResturantownerView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i10.ResturantownerView(),
        settings: data,
      );
    },
    _i11.ResturanttableView: (data) {
      final args = data.getArgs<ResturanttableViewArguments>(nullOk: false);
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i11.ResturanttableView(key: args.key, user: args.user),
        settings: data,
      );
    },
    _i12.ResturantcompleteView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i12.ResturantcompleteView(),
        settings: data,
      );
    },
    _i13.ResturantmenuView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i13.ResturantmenuView(),
        settings: data,
      );
    },
    _i14.UserresturantviewView: (data) {
      final args = data.getArgs<UserresturantviewViewArguments>(nullOk: false);
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => _i14.UserresturantviewView(
            key: args.key,
            table: args.table,
            people: args.people,
            date: args.date,
            timee: args.timee,
            times: args.times),
        settings: data,
      );
    },
    _i15.BooknowView: (data) {
      final args = data.getArgs<BooknowViewArguments>(nullOk: false);
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => _i15.BooknowView(
            key: args.key,
            table: args.table,
            menu: args.menu,
            people: args.people,
            date: args.date,
            timee: args.timee,
            times: args.times),
        settings: data,
      );
    },
    _i16.UserordersView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i16.UserordersView(),
        settings: data,
      );
    },
    _i17.WalletView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i17.WalletView(),
        settings: data,
      );
    },
    _i18.ResturantorderView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i18.ResturantorderView(),
        settings: data,
      );
    },
    _i19.AnalyticsView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i19.AnalyticsView(),
        settings: data,
      );
    },
    _i20.ReviewsView: (data) {
      final args = data.getArgs<ReviewsViewArguments>(nullOk: false);
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => _i20.ReviewsView(key: args.key, data: args.data),
        settings: data,
      );
    },
    _i21.VirtualgiftView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i21.VirtualgiftView(),
        settings: data,
      );
    },
    _i22.AllchatsView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => const _i22.AllchatsView(),
        settings: data,
      );
    },
    _i23.ChatingView: (data) {
      final args = data.getArgs<ChatingViewArguments>(nullOk: false);
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i23.ChatingView(key: args.key, id: args.id, did: args.did),
        settings: data,
      );
    },
    _i24.UsercatviewView: (data) {
      return _i25.MaterialPageRoute<dynamic>(
        builder: (context) => _i24.UsercatviewView(
          cat: "",
        ),
        settings: data,
      );
    },
  };

  @override
  List<_i1.RouteDef> get routes => _routes;

  @override
  Map<Type, _i1.StackedRouteFactory> get pagesMap => _pagesMap;
}

class OtpViewArguments {
  const OtpViewArguments({
    this.key,
    required this.id,
  });

  final _i25.Key? key;

  final String id;

  @override
  String toString() {
    return '{"key": "$key", "id": "$id"}';
  }

  @override
  bool operator ==(covariant OtpViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.id == id;
  }

  @override
  int get hashCode {
    return key.hashCode ^ id.hashCode;
  }
}

class ResturanttableViewArguments {
  const ResturanttableViewArguments({
    this.key,
    required this.user,
  });

  final _i25.Key? key;

  final bool user;

  @override
  String toString() {
    return '{"key": "$key", "user": "$user"}';
  }

  @override
  bool operator ==(covariant ResturanttableViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.user == user;
  }

  @override
  int get hashCode {
    return key.hashCode ^ user.hashCode;
  }
}

class UserresturantviewViewArguments {
  const UserresturantviewViewArguments({
    this.key,
    required this.table,
    required this.people,
    required this.date,
    required this.timee,
    required this.times,
  });

  final _i25.Key? key;

  final String table;

  final String people;

  final String date;

  final String timee;

  final String times;

  @override
  String toString() {
    return '{"key": "$key", "table": "$table", "people": "$people", "date": "$date", "timee": "$timee", "times": "$times"}';
  }

  @override
  bool operator ==(covariant UserresturantviewViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.table == table &&
        other.people == people &&
        other.date == date &&
        other.timee == timee &&
        other.times == times;
  }

  @override
  int get hashCode {
    return key.hashCode ^
        table.hashCode ^
        people.hashCode ^
        date.hashCode ^
        timee.hashCode ^
        times.hashCode;
  }
}

class BooknowViewArguments {
  const BooknowViewArguments({
    this.key,
    required this.table,
    required this.menu,
    required this.people,
    required this.date,
    required this.timee,
    required this.times,
  });

  final _i25.Key? key;

  final String table;

  final List<dynamic> menu;

  final String people;

  final String date;

  final String timee;

  final String times;

  @override
  String toString() {
    return '{"key": "$key", "table": "$table", "menu": "$menu", "people": "$people", "date": "$date", "timee": "$timee", "times": "$times"}';
  }

  @override
  bool operator ==(covariant BooknowViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.table == table &&
        other.menu == menu &&
        other.people == people &&
        other.date == date &&
        other.timee == timee &&
        other.times == times;
  }

  @override
  int get hashCode {
    return key.hashCode ^
        table.hashCode ^
        menu.hashCode ^
        people.hashCode ^
        date.hashCode ^
        timee.hashCode ^
        times.hashCode;
  }
}

class ReviewsViewArguments {
  const ReviewsViewArguments({
    this.key,
    required this.data,
  });

  final _i25.Key? key;

  final Map<dynamic, dynamic> data;

  @override
  String toString() {
    return '{"key": "$key", "data": "$data"}';
  }

  @override
  bool operator ==(covariant ReviewsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.data == data;
  }

  @override
  int get hashCode {
    return key.hashCode ^ data.hashCode;
  }
}

class ChatingViewArguments {
  const ChatingViewArguments({
    this.key,
    required this.id,
    required this.did,
  });

  final _i25.Key? key;

  final String id;

  final String did;

  @override
  String toString() {
    return '{"key": "$key", "id": "$id", "did": "$did"}';
  }

  @override
  bool operator ==(covariant ChatingViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.id == id && other.did == did;
  }

  @override
  int get hashCode {
    return key.hashCode ^ id.hashCode ^ did.hashCode;
  }
}

extension NavigatorStateExtension on _i26.NavigationService {
  Future<dynamic> navigateToHomeView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.homeView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToStartupView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.startupView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToLoginView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.loginView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToSignupView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.signupView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToDetailsView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.detailsView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToOtpView({
    _i25.Key? key,
    required String id,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.otpView,
        arguments: OtpViewArguments(key: key, id: id),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToPicView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.picView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAddpassView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.addpassView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToResturantownerView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.resturantownerView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToResturanttableView({
    _i25.Key? key,
    required bool user,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.resturanttableView,
        arguments: ResturanttableViewArguments(key: key, user: user),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToResturantcompleteView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.resturantcompleteView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToResturantmenuView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.resturantmenuView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToUserresturantviewView({
    _i25.Key? key,
    required String table,
    required String people,
    required String date,
    required String timee,
    required String times,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.userresturantviewView,
        arguments: UserresturantviewViewArguments(
            key: key,
            table: table,
            people: people,
            date: date,
            timee: timee,
            times: times),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToBooknowView({
    _i25.Key? key,
    required String table,
    required List<dynamic> menu,
    required String people,
    required String date,
    required String timee,
    required String times,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.booknowView,
        arguments: BooknowViewArguments(
            key: key,
            table: table,
            menu: menu,
            people: people,
            date: date,
            timee: timee,
            times: times),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToUserordersView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.userordersView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToWalletView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.walletView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToResturantorderView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.resturantorderView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAnalyticsView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.analyticsView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToReviewsView({
    _i25.Key? key,
    required Map<dynamic, dynamic> data,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.reviewsView,
        arguments: ReviewsViewArguments(key: key, data: data),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToVirtualgiftView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.virtualgiftView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAllchatsView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.allchatsView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToChatingView({
    _i25.Key? key,
    required String id,
    required String did,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.chatingView,
        arguments: ChatingViewArguments(key: key, id: id, did: did),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToUsercatviewView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.usercatviewView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithHomeView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.homeView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithStartupView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.startupView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithLoginView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.loginView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithSignupView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.signupView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithDetailsView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.detailsView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithOtpView({
    _i25.Key? key,
    required String id,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.otpView,
        arguments: OtpViewArguments(key: key, id: id),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithPicView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.picView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAddpassView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.addpassView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithResturantownerView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.resturantownerView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithResturanttableView({
    _i25.Key? key,
    required bool user,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.resturanttableView,
        arguments: ResturanttableViewArguments(key: key, user: user),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithResturantcompleteView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.resturantcompleteView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithResturantmenuView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.resturantmenuView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithUserresturantviewView({
    _i25.Key? key,
    required String table,
    required String people,
    required String date,
    required String timee,
    required String times,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.userresturantviewView,
        arguments: UserresturantviewViewArguments(
            key: key,
            table: table,
            people: people,
            date: date,
            timee: timee,
            times: times),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithBooknowView({
    _i25.Key? key,
    required String table,
    required List<dynamic> menu,
    required String people,
    required String date,
    required String timee,
    required String times,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.booknowView,
        arguments: BooknowViewArguments(
            key: key,
            table: table,
            menu: menu,
            people: people,
            date: date,
            timee: timee,
            times: times),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithUserordersView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.userordersView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithWalletView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.walletView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithResturantorderView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.resturantorderView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAnalyticsView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.analyticsView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithReviewsView({
    _i25.Key? key,
    required Map<dynamic, dynamic> data,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.reviewsView,
        arguments: ReviewsViewArguments(key: key, data: data),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithVirtualgiftView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.virtualgiftView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAllchatsView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.allchatsView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithChatingView({
    _i25.Key? key,
    required String id,
    required String did,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.chatingView,
        arguments: ChatingViewArguments(key: key, id: id, did: did),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithUsercatviewView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.usercatviewView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }
}
