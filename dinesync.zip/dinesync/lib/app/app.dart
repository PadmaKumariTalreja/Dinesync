import 'package:dinesync/ui/bottom_sheets/notice/notice_sheet.dart';
import 'package:dinesync/ui/dialogs/info_alert/info_alert_dialog.dart';
import 'package:dinesync/ui/views/home/home_view.dart';
import 'package:dinesync/ui/views/startup/startup_view.dart';
import 'package:stacked/stacked_annotations.dart';
import 'package:stacked_services/stacked_services.dart';
import 'package:dinesync/services/sharedpref_service.dart';
import 'package:dinesync/services/fire_service.dart';
import 'package:dinesync/ui/views/login/login_view.dart';
import 'package:dinesync/ui/views/signup/signup_view.dart';
import 'package:dinesync/ui/views/details/details_view.dart';
import 'package:dinesync/ui/views/otp/otp_view.dart';
import 'package:dinesync/ui/views/pic/pic_view.dart';
import 'package:dinesync/ui/views/addpass/addpass_view.dart';
import 'package:dinesync/ui/views/resturantowner/resturantowner_view.dart';
import 'package:dinesync/ui/views/resturanttable/resturanttable_view.dart';
import 'package:dinesync/ui/views/resturantcomplete/resturantcomplete_view.dart';
import 'package:dinesync/ui/views/resturantmenu/resturantmenu_view.dart';
import 'package:dinesync/ui/views/userresturantview/userresturantview_view.dart';
import 'package:dinesync/ui/views/booknow/booknow_view.dart';
import 'package:dinesync/ui/views/userorders/userorders_view.dart';
import 'package:dinesync/ui/views/wallet/wallet_view.dart';
import 'package:dinesync/ui/views/resturantorder/resturantorder_view.dart';
import 'package:dinesync/ui/views/analytics/analytics_view.dart';
import 'package:dinesync/ui/views/reviews/reviews_view.dart';
import 'package:dinesync/ui/views/virtualgift/virtualgift_view.dart';
import 'package:dinesync/ui/views/chat/allchats/allchats_view.dart';
import 'package:dinesync/ui/views/chat/chating/chating_view.dart';
import 'package:dinesync/ui/views/usercatview/usercatview_view.dart';
// @stacked-import

@StackedApp(
  routes: [
    MaterialRoute(page: HomeView),
    MaterialRoute(page: StartupView),
    MaterialRoute(page: LoginView),
    MaterialRoute(page: SignupView),
    MaterialRoute(page: DetailsView),
    MaterialRoute(page: OtpView),
    MaterialRoute(page: PicView),
    MaterialRoute(page: AddpassView),
    MaterialRoute(page: ResturantownerView),
    MaterialRoute(page: ResturanttableView),
    MaterialRoute(page: ResturantcompleteView),
    MaterialRoute(page: ResturantmenuView),
    MaterialRoute(page: UserresturantviewView),
    MaterialRoute(page: BooknowView),
    MaterialRoute(page: UserordersView),
    MaterialRoute(page: WalletView),
    MaterialRoute(page: ResturantorderView),
    MaterialRoute(page: AnalyticsView),
    MaterialRoute(page: ReviewsView),
    MaterialRoute(page: VirtualgiftView),
    MaterialRoute(page: AllchatsView),
    MaterialRoute(page: ChatingView),
    MaterialRoute(page: UsercatviewView),
// @stacked-route
  ],
  dependencies: [
    LazySingleton(classType: BottomSheetService),
    LazySingleton(classType: DialogService),
    LazySingleton(classType: NavigationService),
    LazySingleton(classType: SharedprefService),
    LazySingleton(classType: FireService),
// @stacked-service
  ],
  bottomsheets: [
    StackedBottomsheet(classType: NoticeSheet),
    // @stacked-bottom-sheet
  ],
  dialogs: [
    StackedDialog(classType: InfoAlertDialog),
    // @stacked-dialog
  ],
)
class App {}
